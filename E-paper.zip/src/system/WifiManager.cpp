#include "system/WifiManager.h"

#include <FS.h>
#include <HTTPClient.h>
#include <ESPmDNS.h>
#include <SD.h>
#include <SPIFFS.h>
#include <Wire.h>
#include <WebServer.h>
#include <WiFi.h>
#include <Preferences.h>
#include <sys/time.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <esp_adc_cal.h>
#include <esp_sntp.h>
#include <esp_wifi.h>
#include <esp_wpa2.h>

#include "system/CalendarSettings.h"
#include "system/CalendarEventNormalize.h"
#include "system/CalendarIcsCore.h"
#include "system/CalendarSyncService.h"
#include "system/LogConfig.h"
#include "system/SdCard.h"
#include "system/SettingsStore.h"

namespace appfw {
namespace {
constexpr const char *kDefaultApSsid = "PhotoFrame_Config";
constexpr const char *kDefaultApPass = "12345678";
constexpr const char *kDefaultHostname = "epaper";
constexpr const char *kPortalHtmlPath = "/portal.html";
constexpr uint16_t kHttpPort = 80;
constexpr uint8_t kI2cSdaPin = 21;
constexpr uint8_t kI2cSclPin = 22;
constexpr uint8_t kAht20Address = 0x38;
constexpr uint8_t kRx8025Address = 0x32;
constexpr time_t kMinTrustedEpoch = 1704067200;  // 2024-01-01 00:00:00 UTC.

int32_t dayIdFromTm(const struct tm &tm_value) {
  return static_cast<int32_t>((tm_value.tm_year + 1900) * 10000 + (tm_value.tm_mon + 1) * 100 +
                              tm_value.tm_mday);
}

String formatDateYmd(const struct tm &tm_value) {
  char buf[16] = {0};
  snprintf(buf, sizeof(buf), "%04d-%02d-%02d", tm_value.tm_year + 1900, tm_value.tm_mon + 1,
           tm_value.tm_mday);
  return String(buf);
}

String formatTimeHm(const struct tm &tm_value) {
  char buf[8] = {0};
  snprintf(buf, sizeof(buf), "%02d:%02d", tm_value.tm_hour, tm_value.tm_min);
  return String(buf);
}

String formatDateTimeYmdHm(time_t epoch_value) {
  struct tm tm_value {};
  if (localtime_r(&epoch_value, &tm_value) == nullptr) {
    return String("invalid");
  }
  char buf[20] = {0};
  snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d", tm_value.tm_year + 1900,
           tm_value.tm_mon + 1, tm_value.tm_mday, tm_value.tm_hour, tm_value.tm_min);
  return String(buf);
}

String formatMinuteHm(uint16_t minute_of_day) {
  if (minute_of_day >= 1440u) {
    minute_of_day = 0;
  }
  char buf[8] = {0};
  snprintf(buf, sizeof(buf), "%02u:%02u",
           static_cast<unsigned>(minute_of_day / 60u),
           static_cast<unsigned>(minute_of_day % 60u));
  return String(buf);
}

bool parseMinuteHm(const String &raw, uint16_t &minute_out) {
  String normalized;
  if (!normalizeCalendarTimeValue(raw, normalized)) {
    return false;
  }
  minute_out = static_cast<uint16_t>(
      normalized.substring(0, 2).toInt() * 60 + normalized.substring(3, 5).toInt());
  return true;
}

void mixCalendarHashByte(uint32_t &hash, uint8_t value) {
  hash ^= value;
  hash *= 16777619UL;
}

void mixCalendarHashString(uint32_t &hash, const String &value) {
  for (size_t i = 0; i < value.length(); ++i) {
    mixCalendarHashByte(hash, static_cast<uint8_t>(value[i]));
  }
  mixCalendarHashByte(hash, 0xFFu);
}

void mixCalendarHashInt(uint32_t &hash, uint32_t value) {
  for (uint8_t i = 0; i < 4u; ++i) {
    mixCalendarHashByte(hash, static_cast<uint8_t>((value >> (i * 8u)) & 0xFFu));
  }
}

uint8_t bcdToDec(uint8_t value) {
  return static_cast<uint8_t>(((value >> 4) * 10u) + (value & 0x0Fu));
}

uint8_t decToBcd(uint8_t value) {
  return static_cast<uint8_t>(((value / 10u) << 4) | (value % 10u));
}

int64_t daysFromCivil(int year, unsigned month, unsigned day) {
  year -= month <= 2;
  const int era = (year >= 0 ? year : year - 399) / 400;
  const unsigned yoe = static_cast<unsigned>(year - era * 400);
  const unsigned doy = (153 * (month + (month > 2 ? -3 : 9)) + 2) / 5 + day - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return static_cast<int64_t>(era) * 146097 + static_cast<int64_t>(doe) - 719468;
}

time_t epochFromUtcTm(const struct tm &tm_value) {
  const int year = tm_value.tm_year + 1900;
  const unsigned month = static_cast<unsigned>(tm_value.tm_mon + 1);
  const unsigned day = static_cast<unsigned>(tm_value.tm_mday);
  const int64_t days = daysFromCivil(year, month, day);
  const int64_t seconds = days * 86400LL +
                          static_cast<int64_t>(tm_value.tm_hour) * 3600LL +
                          static_cast<int64_t>(tm_value.tm_min) * 60LL +
                          static_cast<int64_t>(tm_value.tm_sec);
  return static_cast<time_t>(seconds);
}

bool isTrustedEpoch(time_t epoch_value) {
  return epoch_value >= kMinTrustedEpoch;
}

const char *sntpSyncStatusName(sntp_sync_status_t status) {
  switch (status) {
    case SNTP_SYNC_STATUS_RESET:
      return "reset";
    case SNTP_SYNC_STATUS_COMPLETED:
      return "completed";
    case SNTP_SYNC_STATUS_IN_PROGRESS:
      return "in_progress";
    default:
      return "unknown";
  }
}

bool readRx8025Utc(time_t &epoch_value) {
  epoch_value = 0;
  Wire.beginTransmission(kRx8025Address);
  Wire.write(0x00);
  if (Wire.endTransmission(false) != 0) {
    return false;
  }
  const int len = Wire.requestFrom(static_cast<int>(kRx8025Address), 7);
  if (len != 7) {
    return false;
  }
  uint8_t data[7] = {};
  for (uint8_t i = 0; i < 7; ++i) {
    if (!Wire.available()) {
      return false;
    }
    data[i] = static_cast<uint8_t>(Wire.read());
  }

  struct tm tm_utc {};
  tm_utc.tm_sec = bcdToDec(data[0] & 0x7F);
  tm_utc.tm_min = bcdToDec(data[1] & 0x7F);
  tm_utc.tm_hour = bcdToDec(data[2] & 0x3F);
  tm_utc.tm_mday = bcdToDec(data[4] & 0x3F);
  tm_utc.tm_mon = bcdToDec(data[5] & 0x1F) - 1;
  tm_utc.tm_year = bcdToDec(data[6]) + 100;
  if (tm_utc.tm_sec > 59 || tm_utc.tm_min > 59 || tm_utc.tm_hour > 23 ||
      tm_utc.tm_mday < 1 || tm_utc.tm_mday > 31 || tm_utc.tm_mon < 0 ||
      tm_utc.tm_mon > 11) {
    return false;
  }
  epoch_value = epochFromUtcTm(tm_utc);
  return isTrustedEpoch(epoch_value);
}

bool writeRx8025Utc(time_t epoch_value) {
  if (!isTrustedEpoch(epoch_value)) {
    return false;
  }
  struct tm tm_utc {};
  if (gmtime_r(&epoch_value, &tm_utc) == nullptr) {
    return false;
  }

  Wire.beginTransmission(kRx8025Address);
  Wire.write(0x00);
  Wire.write(decToBcd(static_cast<uint8_t>(tm_utc.tm_sec)));
  Wire.write(decToBcd(static_cast<uint8_t>(tm_utc.tm_min)));
  Wire.write(decToBcd(static_cast<uint8_t>(tm_utc.tm_hour)));
  Wire.write(static_cast<uint8_t>(1u << tm_utc.tm_wday));
  Wire.write(decToBcd(static_cast<uint8_t>(tm_utc.tm_mday)));
  Wire.write(decToBcd(static_cast<uint8_t>(tm_utc.tm_mon + 1)));
  Wire.write(decToBcd(static_cast<uint8_t>((tm_utc.tm_year + 1900) % 100)));
  return Wire.endTransmission() == 0;
}

String jsonEscape(const String &s) {
  String out;
  out.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); ++i) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    if (c == '\\') {
      out += "\\\\";
    } else if (c == '"') {
      out += "\\\"";
    } else if (c == '\n') {
      out += "\\n";
    } else if (c == '\r') {
      out += "\\r";
    } else if (c == '\t') {
      out += "\\t";
    } else if (c < 0x20u) {
      char escaped[7] = {0};
      snprintf(escaped, sizeof(escaped), "\\u%04X", static_cast<unsigned>(c));
      out += escaped;
    } else {
      out += static_cast<char>(c);
    }
  }
  return out;
}

String urlEncode(const String &s) {
  static const char hex[] = "0123456789ABCDEF";
  String out;
  out.reserve(s.length() * 3);
  for (size_t i = 0; i < s.length(); ++i) {
    const uint8_t c = static_cast<uint8_t>(s[i]);
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out += static_cast<char>(c);
    } else {
      out += '%';
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }
  return out;
}

int hexToInt(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

String urlDecode(const String &s) {
  String out;
  out.reserve(s.length());
  for (size_t i = 0; i < s.length(); ++i) {
    const char c = s[i];
    if (c == '%' && (i + 2) < s.length()) {
      const int hi = hexToInt(s[i + 1]);
      const int lo = hexToInt(s[i + 2]);
      if (hi >= 0 && lo >= 0) {
        out += static_cast<char>((hi << 4) | lo);
        i += 2;
        continue;
      }
    }
    if (c == '+') {
      out += ' ';
    } else {
      out += c;
    }
  }
  return out;
}

bool isLeapYear(int year) {
  return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}

int daysInMonth(int year, int month) {
  static const int kDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if (month == 2 && isLeapYear(year)) {
    return 29;
  }
  if (month < 1 || month > 12) {
    return 30;
  }
  return kDays[month - 1];
}

bool parseYmdDate(const String &raw, int &year, int &month, int &day) {
  if (raw.length() != 10 || raw.charAt(4) != '-' || raw.charAt(7) != '-') {
    return false;
  }
  year = raw.substring(0, 4).toInt();
  month = raw.substring(5, 7).toInt();
  day = raw.substring(8, 10).toInt();
  return year >= 2020 && month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth(year, month);
}

time_t localEpochFromYmdHm(const String &date, const String &time_hhmm) {
  int year = 0;
  int month = 0;
  int day = 0;
  if (!parseYmdDate(date, year, month, day)) {
    return 0;
  }
  uint16_t minute = 0;
  if (!parseMinuteHm(time_hhmm, minute)) {
    return 0;
  }
  struct tm tm_value {};
  tm_value.tm_year = year - 1900;
  tm_value.tm_mon = month - 1;
  tm_value.tm_mday = day;
  tm_value.tm_hour = static_cast<int>(minute / 60u);
  tm_value.tm_min = static_cast<int>(minute % 60u);
  tm_value.tm_sec = 0;
  tm_value.tm_isdst = -1;
  return mktime(&tm_value);
}

time_t startOfLocalDay(time_t epoch_value, struct tm &local_tm) {
  if (localtime_r(&epoch_value, &local_tm) == nullptr) {
    memset(&local_tm, 0, sizeof(local_tm));
    return 0;
  }
  local_tm.tm_hour = 0;
  local_tm.tm_min = 0;
  local_tm.tm_sec = 0;
  local_tm.tm_isdst = -1;
  return mktime(&local_tm);
}

bool nextManualEventEpoch(const CalendarEvent &event, time_t now_epoch, time_t &next_epoch,
                          String &occurrence_date) {
  next_epoch = 0;
  occurrence_date = event.date;
  if (event.source == "ics") {
    return false;
  }
  uint16_t minute = 0;
  if (!parseMinuteHm(event.time_hhmm, minute)) {
    return false;
  }
  if (event.repeat == "once") {
    next_epoch = localEpochFromYmdHm(event.date, event.time_hhmm);
    occurrence_date = event.date;
    return next_epoch > 0 && (now_epoch <= 0 || next_epoch >= now_epoch);
  }

  if (now_epoch <= 0) {
    next_epoch = 1;
    occurrence_date = event.date;
    return true;
  }

  struct tm day_tm {};
  time_t day_start = startOfLocalDay(now_epoch, day_tm);
  if (day_start <= 0) {
    return false;
  }

  uint8_t days_ahead = 0;
  if (event.repeat == "weekly") {
    if (event.weekday < 0 || event.weekday > 6) {
      return false;
    }
    const int today_weekday = (day_tm.tm_wday + 6) % 7;
    days_ahead = static_cast<uint8_t>((event.weekday - today_weekday + 7) % 7);
  } else if (event.repeat != "daily") {
    return false;
  }

  next_epoch = day_start + static_cast<time_t>(days_ahead) * 86400L +
               static_cast<time_t>(minute) * 60L;
  if (next_epoch < now_epoch) {
    next_epoch += (event.repeat == "weekly") ? static_cast<time_t>(7 * 86400L)
                                             : static_cast<time_t>(86400L);
  }
  struct tm next_tm {};
  if (localtime_r(&next_epoch, &next_tm) != nullptr) {
    occurrence_date = formatDateYmd(next_tm);
  }
  return true;
}

struct UpcomingCalendarEvent {
  CalendarEvent event;
  time_t epoch = 0;
  uint16_t order = 0;
};

bool upcomingEventLess(const UpcomingCalendarEvent &a, const UpcomingCalendarEvent &b) {
  if (a.epoch != b.epoch) {
    return a.epoch < b.epoch;
  }
  if (a.event.title != b.event.title) {
    return a.event.title < b.event.title;
  }
  return a.order < b.order;
}

void appendCalendarEventJson(String &item, const CalendarEvent &event) {
  item += "{\"id\":";
  item += String(event.id);
  item += ",\"title\":\"";
  item += jsonEscape(event.title);
  item += "\",\"date\":\"";
  item += jsonEscape(event.date);
  item += "\",\"time\":\"";
  item += jsonEscape(event.time_hhmm);
  item += "\",\"end_time\":\"";
  item += jsonEscape(event.end_time_hhmm);
  item += "\",\"color\":\"";
  item += jsonEscape(event.color);
  item += "\",\"repeat\":\"";
  item += jsonEscape(event.repeat);
  item += "\",\"weekday\":";
  item += String(event.weekday);
  item += ",\"source\":\"";
  item += jsonEscape(event.source);
  item += "\",\"external_id\":\"";
  item += jsonEscape(event.external_id);
  item += "\",\"updated_at\":\"";
  item += jsonEscape(event.updated_at);
  item += "\"}";
}

String extractJsonStringField(const String &json, const char *key) {
  if (key == nullptr || key[0] == '\0') {
    return "";
  }
  const String token = String("\"") + key + "\":\"";
  const int start = json.indexOf(token);
  if (start < 0) {
    return "";
  }

  String out;
  out.reserve(48);
  bool escaping = false;
  for (int i = start + static_cast<int>(token.length()); i < static_cast<int>(json.length()); ++i) {
    const char c = json[i];
    if (escaping) {
      switch (c) {
        case '\"':
          out += '\"';
          break;
        case '\\':
          out += '\\';
          break;
        case '/':
          out += '/';
          break;
        case 'b':
          out += '\b';
          break;
        case 'f':
          out += '\f';
          break;
        case 'n':
          out += '\n';
          break;
        case 'r':
          out += '\r';
          break;
        case 't':
          out += '\t';
          break;
        default:
          out += c;
          break;
      }
      escaping = false;
      continue;
    }
    if (c == '\\') {
      escaping = true;
      continue;
    }
    if (c == '"') {
      break;
    }
    out += c;
  }
  out.trim();
  return out;
}

bool extractJsonIntField(const String &json, const char *key, int32_t &value) {
  value = 0;
  if (key == nullptr || key[0] == '\0') {
    return false;
  }
  const String token = String("\"") + key + "\":";
  int search_start = 0;
  while (search_start < static_cast<int>(json.length())) {
    const int start = json.indexOf(token, search_start);
    if (start < 0) {
      return false;
    }

    int pos = start + static_cast<int>(token.length());
    while (pos < static_cast<int>(json.length()) &&
           (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\r' || json[pos] == '\n')) {
      ++pos;
    }
    if (pos >= static_cast<int>(json.length())) {
      return false;
    }

    int end = pos;
    if (json[end] == '-') {
      ++end;
    }
    bool saw_digit = false;
    while (end < static_cast<int>(json.length()) && isDigit(json[end])) {
      saw_digit = true;
      ++end;
    }
    if (saw_digit) {
      value = static_cast<int32_t>(json.substring(pos, end).toInt());
      return true;
    }
    search_start = pos + 1;
  }
  return false;
}

String posixTimezoneFromUtcOffsetSeconds(int32_t utc_offset_seconds) {
  const long posix_offset = static_cast<long>(-utc_offset_seconds);
  const long abs_offset = labs(posix_offset);
  const long hours = abs_offset / 3600L;
  const long minutes = (abs_offset % 3600L) / 60L;
  const long seconds = abs_offset % 60L;

  String tz = "UTC";
  if (posix_offset > 0) {
    tz += "+";
  } else if (posix_offset < 0) {
    tz += "-";
  } else {
    tz += "0";
    return tz;
  }
  tz += String(hours);
  if (minutes != 0 || seconds != 0) {
    if (minutes < 10) tz += ":0";
    else tz += ":";
    tz += String(minutes);
    if (seconds != 0) {
      if (seconds < 10) tz += ":0";
      else tz += ":";
      tz += String(seconds);
    }
  }
  return tz;
}

String timezoneForEsp(const String &timezone_name, bool has_utc_offset, int32_t utc_offset_seconds) {
  if (has_utc_offset) {
    return posixTimezoneFromUtcOffsetSeconds(utc_offset_seconds);
  }

  String tz = timezone_name;
  tz.trim();
  if (tz.length() == 0) {
    return "";
  }
  if (tz == "Asia/Shanghai") return "CST-8";
  if (tz == "UTC" || tz == "Etc/UTC" || tz == "GMT") return "UTC0";
  if (tz.indexOf('/') >= 0) {
    return "";
  }
  return tz;
}

bool syncClockWithTimezone(const String &timezone, String &local_time, String &error_msg) {
  local_time = "";
  error_msg = "";
  if (timezone.length() == 0) {
    error_msg = "empty_timezone";
    return false;
  }

  const time_t before_sync = time(nullptr);
  sntp_set_sync_status(SNTP_SYNC_STATUS_RESET);
  configTzTime(timezone.c_str(), "ntp.aliyun.com", "time.cloudflare.com", "pool.ntp.org");
  constexpr time_t kMinValidEpoch = 1700000000;  // About 2023-11.
  const uint32_t start_ms = millis();
  sntp_sync_status_t last_status = SNTP_SYNC_STATUS_RESET;
  Serial.printf("[TIME] ntp sync start tz=%s before_epoch=%ld\n",
                timezone.c_str(), static_cast<long>(before_sync));
  while ((millis() - start_ms) < 10000) {
    const time_t now_ts = time(nullptr);
    const sntp_sync_status_t status = sntp_get_sync_status();
    if (status != last_status) {
      if (kDebugLogs) {
        Serial.printf("[TIME] ntp status=%s epoch=%ld\n",
                      sntpSyncStatusName(status), static_cast<long>(now_ts));
      }
      last_status = status;
    }
    if (status == SNTP_SYNC_STATUS_COMPLETED && now_ts >= kMinValidEpoch) {
      struct tm tm_local {};
      if (localtime_r(&now_ts, &tm_local) == nullptr) {
        error_msg = "localtime_failed";
        return false;
      }
      char buf[40] = {0};
      if (strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S %z", &tm_local) > 0) {
        local_time = String(buf);
      } else {
        local_time = String(static_cast<unsigned long>(now_ts));
      }
      Serial.printf("[TIME] ntp sync completed epoch=%ld local=%s\n",
                    static_cast<long>(now_ts), local_time.c_str());
      return true;
    }
    delay(200);
  }
  error_msg = "ntp_timeout_status_";
  error_msg += sntpSyncStatusName(sntp_get_sync_status());
  error_msg += "_epoch_";
  error_msg += String(static_cast<long>(time(nullptr)));
  return false;
}

}  // namespace

void WifiManager::registerWifiEvents() {
  if (wifi_events_registered_) {
    return;
  }
  WiFi.onEvent([this](WiFiEvent_t event, WiFiEventInfo_t info) {
    handleWifiEvent(event, info);
  });
  wifi_events_registered_ = true;
}

void WifiManager::handleWifiEvent(arduino_event_id_t event, arduino_event_info_t info) {
  switch (event) {
    case ARDUINO_EVENT_WIFI_STA_START:
      Serial.println("[WIFI][EVT] STA_START");
      break;
    case ARDUINO_EVENT_WIFI_STA_STOP:
      Serial.println("[WIFI][EVT] STA_STOP");
      break;
    case ARDUINO_EVENT_WIFI_STA_CONNECTED:
      Serial.printf("[WIFI][EVT] STA_CONNECTED ssid=%s channel=%d auth=%d\n",
                    reinterpret_cast<const char *>(info.wifi_sta_connected.ssid),
                    static_cast<int>(info.wifi_sta_connected.channel),
                    static_cast<int>(info.wifi_sta_connected.authmode));
      break;
    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
      Serial.printf("[WIFI][EVT] STA_DISCONNECTED reason=%u (%s) ssid=%s\n",
                    static_cast<unsigned>(info.wifi_sta_disconnected.reason),
                    disconnectReasonName(info.wifi_sta_disconnected.reason),
                    reinterpret_cast<const char *>(info.wifi_sta_disconnected.ssid));
      break;
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
      Serial.printf("[WIFI][EVT] STA_GOT_IP ip=%s gw=%s mask=%s\n",
                    IPAddress(info.got_ip.ip_info.ip.addr).toString().c_str(),
                    IPAddress(info.got_ip.ip_info.gw.addr).toString().c_str(),
                    IPAddress(info.got_ip.ip_info.netmask.addr).toString().c_str());
      break;
    case ARDUINO_EVENT_WIFI_STA_LOST_IP:
      Serial.println("[WIFI][EVT] STA_LOST_IP");
      break;
    default:
      Serial.printf("[WIFI][EVT] %s (%d)\n", wifiEventName(event), static_cast<int>(event));
      break;
  }
}

const char *WifiManager::wifiStatusName(int status) const {
  switch (status) {
    case WL_IDLE_STATUS:
      return "WL_IDLE_STATUS";
    case WL_NO_SSID_AVAIL:
      return "WL_NO_SSID_AVAIL";
    case WL_SCAN_COMPLETED:
      return "WL_SCAN_COMPLETED";
    case WL_CONNECTED:
      return "WL_CONNECTED";
    case WL_CONNECT_FAILED:
      return "WL_CONNECT_FAILED";
    case WL_CONNECTION_LOST:
      return "WL_CONNECTION_LOST";
    case WL_DISCONNECTED:
      return "WL_DISCONNECTED";
    default:
      return "WL_UNKNOWN";
  }
}

const char *WifiManager::wifiEventName(arduino_event_id_t event) const {
  switch (event) {
    case ARDUINO_EVENT_WIFI_READY:
      return "WIFI_READY";
    case ARDUINO_EVENT_WIFI_SCAN_DONE:
      return "WIFI_SCAN_DONE";
    case ARDUINO_EVENT_WIFI_STA_START:
      return "WIFI_STA_START";
    case ARDUINO_EVENT_WIFI_STA_STOP:
      return "WIFI_STA_STOP";
    case ARDUINO_EVENT_WIFI_STA_CONNECTED:
      return "WIFI_STA_CONNECTED";
    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
      return "WIFI_STA_DISCONNECTED";
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
      return "WIFI_STA_GOT_IP";
    case ARDUINO_EVENT_WIFI_STA_LOST_IP:
      return "WIFI_STA_LOST_IP";
    case ARDUINO_EVENT_WIFI_AP_START:
      return "WIFI_AP_START";
    case ARDUINO_EVENT_WIFI_AP_STOP:
      return "WIFI_AP_STOP";
    case ARDUINO_EVENT_WIFI_AP_STACONNECTED:
      return "WIFI_AP_STACONNECTED";
    case ARDUINO_EVENT_WIFI_AP_STADISCONNECTED:
      return "WIFI_AP_STADISCONNECTED";
    case ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED:
      return "WIFI_AP_STAIPASSIGNED";
    default:
      return "WIFI_EVENT_UNKNOWN";
  }
}

const char *WifiManager::disconnectReasonName(uint8_t reason) const {
  switch (reason) {
    case WIFI_REASON_UNSPECIFIED:
      return "UNSPECIFIED";
    case WIFI_REASON_AUTH_EXPIRE:
      return "AUTH_EXPIRE";
    case WIFI_REASON_AUTH_LEAVE:
      return "AUTH_LEAVE";
    case WIFI_REASON_ASSOC_EXPIRE:
      return "ASSOC_EXPIRE";
    case WIFI_REASON_ASSOC_TOOMANY:
      return "ASSOC_TOOMANY";
    case WIFI_REASON_NOT_AUTHED:
      return "NOT_AUTHED";
    case WIFI_REASON_NOT_ASSOCED:
      return "NOT_ASSOCED";
    case WIFI_REASON_ASSOC_LEAVE:
      return "ASSOC_LEAVE";
    case WIFI_REASON_ASSOC_NOT_AUTHED:
      return "ASSOC_NOT_AUTHED";
    case WIFI_REASON_DISASSOC_PWRCAP_BAD:
      return "DISASSOC_PWRCAP_BAD";
    case WIFI_REASON_DISASSOC_SUPCHAN_BAD:
      return "DISASSOC_SUPCHAN_BAD";
    case WIFI_REASON_IE_INVALID:
      return "IE_INVALID";
    case WIFI_REASON_MIC_FAILURE:
      return "MIC_FAILURE";
    case WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT:
      return "4WAY_HANDSHAKE_TIMEOUT";
    case WIFI_REASON_GROUP_KEY_UPDATE_TIMEOUT:
      return "GROUP_KEY_UPDATE_TIMEOUT";
    case WIFI_REASON_IE_IN_4WAY_DIFFERS:
      return "IE_IN_4WAY_DIFFERS";
    case WIFI_REASON_GROUP_CIPHER_INVALID:
      return "GROUP_CIPHER_INVALID";
    case WIFI_REASON_PAIRWISE_CIPHER_INVALID:
      return "PAIRWISE_CIPHER_INVALID";
    case WIFI_REASON_AKMP_INVALID:
      return "AKMP_INVALID";
    case WIFI_REASON_UNSUPP_RSN_IE_VERSION:
      return "UNSUPP_RSN_IE_VERSION";
    case WIFI_REASON_INVALID_RSN_IE_CAP:
      return "INVALID_RSN_IE_CAP";
    case WIFI_REASON_802_1X_AUTH_FAILED:
      return "8021X_AUTH_FAILED";
    case WIFI_REASON_CIPHER_SUITE_REJECTED:
      return "CIPHER_SUITE_REJECTED";
    case WIFI_REASON_BEACON_TIMEOUT:
      return "BEACON_TIMEOUT";
    case WIFI_REASON_NO_AP_FOUND:
      return "NO_AP_FOUND";
    case WIFI_REASON_AUTH_FAIL:
      return "AUTH_FAIL";
    case WIFI_REASON_ASSOC_FAIL:
      return "ASSOC_FAIL";
    case WIFI_REASON_HANDSHAKE_TIMEOUT:
      return "HANDSHAKE_TIMEOUT";
    default:
      return "UNKNOWN_REASON";
  }
}

void WifiManager::logStaScanResults() {
  if (!kDebugLogs) {
    return;
  }
  Serial.println("[WIFI] STA scan begin");
  WiFi.disconnect(false, false);
  delay(80);
  const int count = WiFi.scanNetworks(false, true, false, 400, 0);
  if (count < 0) {
    Serial.printf("[WIFI] STA scan failed code=%d\n", count);
    return;
  }
  Serial.printf("[WIFI] STA scan found=%d\n", count);
  bool matched = false;
  for (int i = 0; i < count; ++i) {
    const String ssid = WiFi.SSID(i);
    const int32_t rssi = WiFi.RSSI(i);
    const wifi_auth_mode_t enc = WiFi.encryptionType(i);
    const bool is_target = (ssid == settings_.sta_ssid);
    if (is_target) {
      matched = true;
    }
    Serial.printf("[WIFI]   %c #%d ssid=%s rssi=%ld ch=%d enc=%d\n",
                  is_target ? '*' : '-',
                  i + 1,
                  ssid.c_str(),
                  static_cast<long>(rssi),
                  WiFi.channel(i),
                  static_cast<int>(enc));
  }
  if (!matched) {
    Serial.printf("[WIFI] target ssid not seen in scan: %s\n", settings_.sta_ssid.c_str());
  }
  WiFi.scanDelete();
}

void WifiManager::begin() {
  pinMode(kPeripheralPowerPin, OUTPUT);
  digitalWrite(kPeripheralPowerPin, LOW);
  registerWifiEvents();
  initSensors();
  loadSettings();
  stop("boot");
}

void WifiManager::update(uint32_t now_ms) {
  updateSensors(now_ms);
  pruneExpiredCalendarEvents();

  if (server_ != nullptr && (isApSessionActive() || state_ == State::StaRunning)) {
    server_->handleClient();
  }

  if (state_ == State::StaConnecting) {
    const int status = WiFi.status();
    if (status != last_sta_wifi_status_) {
      Serial.printf("[WIFI] STA status -> %s (%d)\n", wifiStatusName(status), status);
      last_sta_wifi_status_ = status;
    }
    if (status == WL_CONNECTED) {
      state_ = State::StaRunning;
      sta_session_start_ms_ = now_ms;
      markActivity(now_ms);
      startServer();
      initSD();
      MDNS.end();
      if (MDNS.begin(kDefaultHostname)) {
        MDNS.addService("http", "tcp", kHttpPort);
        Serial.printf("[WIFI] STA connected ip=%s mdns=http://%s.local/\n",
                      WiFi.localIP().toString().c_str(), kDefaultHostname);
      } else {
        Serial.printf("[WIFI] STA connected ip=%s mdns_start_failed\n",
                      WiFi.localIP().toString().c_str());
      }
      String resolved_timezone;
      String local_time;
      String sync_error;
      String preview;
      String request_error;
      bool timezone_updated = false;
      int http_status = 0;
      if (syncClockFromWeather(resolved_timezone, timezone_updated, local_time, sync_error, preview,
                               http_status, request_error)) {
        Serial.printf("[TIME] synced tz=%s local=%s\n",
                      resolved_timezone.c_str(), local_time.c_str());
        writeClockToRtc("weather_sync");
      } else {
        const String effective_tz = timezoneForEsp(settings_.timezone, false, 0);
        if (syncClockWithTimezone(effective_tz, local_time, sync_error)) {
          Serial.printf("[TIME] fallback synced tz=%s local=%s\n",
                        effective_tz.c_str(), local_time.c_str());
          writeClockToRtc("fallback_ntp");
        } else {
          Serial.printf("[TIME] sync failed weather_err=%s tz=%s err=%s\n",
                        request_error.c_str(), effective_tz.c_str(), sync_error.c_str());
        }
      }
      calendar_sync_pending_ = true;
      last_calendar_sync_ms_ = 0;
    } else if ((now_ms - sta_connect_start_ms_) >= sta_connect_timeout_ms_) {
      Serial.printf("[WIFI] STA connect timeout -> stop (last_status=%s/%d)\n",
                    wifiStatusName(status), status);
      sta_connect_failed_ = true;
      if (isApSessionActive()) {
        stopStaOnly("sta_connect_timeout_keep_ap");
      } else {
        stop("sta_connect_timeout");
        auto_exit_requested_ = true;
      }
    }
    return;
  }

  if (state_ == State::StaRunning && WiFi.status() != WL_CONNECTED) {
    Serial.println("[WIFI] STA lost connection -> stop");
    sta_connect_failed_ = true;
    if (isApSessionActive()) {
      stopStaOnly("sta_lost_connection_keep_ap");
    } else {
      stop("sta_lost_connection");
      auto_exit_requested_ = true;
    }
    return;
  }

  if (state_ == State::StaRunning) {
    maybeSyncCalendarUrl(now_ms);
  }

  updateTimeout(now_ms);
}

void WifiManager::startAP() {
  stop("switch_to_ap");
  digitalWrite(kPeripheralPowerPin, HIGH);
  delay(3);
  WiFi.mode(WIFI_AP_STA);
  WiFi.setHostname(kDefaultHostname);
  const bool ok = WiFi.softAP(kDefaultApSsid, kDefaultApPass);
  if (!ok) {
    Serial.println("[WIFI] AP start failed");
    state_ = State::Idle;
    ap_active_ = false;
    return;
  }

  ap_active_ = true;
  state_ = State::ApRunning;
  markActivity(millis());
  startServer();
  initSD();
  Serial.printf("[WIFI] AP started ssid=%s ip=%s timeout=%lus\n", kDefaultApSsid,
                WiFi.softAPIP().toString().c_str(),
                static_cast<unsigned long>(kApIdleTimeoutMs / 1000));
  Serial.println("[WIFI] portal url: http://192.168.4.1/");
  if (hasStaCredentials()) {
    startSTAWithTimeout(kStaConnectTimeoutManualMs, "ap_config_background");
  } else {
    Serial.println("[WIFI] AP config mode: no STA credentials saved");
  }
}

void WifiManager::startSTA() {
  startSTAWithTimeout(kStaConnectTimeoutManualMs, "manual");
}

void WifiManager::startStaAutoSync() {
  startSTAWithTimeout(kStaConnectTimeoutAutoSyncMs, "auto_sync");
}

void WifiManager::startStaPreRefreshSync() {
  Serial.println("[TIME] pre-refresh time sync required");
  startSTAWithTimeout(kStaConnectTimeoutAutoSyncMs, "calendar_pre_refresh");
}

String WifiManager::effectiveStaAuthMode() const {
  String mode = settings_.sta_auth_mode;
  mode.trim();
  mode.toLowerCase();
  if (mode != "auto") {
    return mode;
  }
  if (settings_.sta_user.length() > 0) {
    return "enterprise";
  }
  if (settings_.sta_pass.length() > 0) {
    return "personal";
  }
  return "open";
}

bool WifiManager::beginStaConnection() {
  const String mode = effectiveStaAuthMode();
  if (mode == "enterprise") {
    if (settings_.sta_user.length() == 0 || settings_.sta_pass.length() == 0) {
      Serial.println("[WIFI] enterprise auth requires account and password");
      return false;
    }
    const unsigned char *identity =
        reinterpret_cast<const unsigned char *>(settings_.sta_user.c_str());
    const unsigned char *password =
        reinterpret_cast<const unsigned char *>(settings_.sta_pass.c_str());
    esp_wifi_sta_wpa2_ent_clear_identity();
    esp_wifi_sta_wpa2_ent_clear_username();
    esp_wifi_sta_wpa2_ent_clear_password();
    esp_wifi_sta_wpa2_ent_set_identity(identity, settings_.sta_user.length());
    esp_wifi_sta_wpa2_ent_set_username(identity, settings_.sta_user.length());
    esp_wifi_sta_wpa2_ent_set_password(password, settings_.sta_pass.length());
    const bool trusted_clock = systemClockTrusted();
    esp_wifi_sta_wpa2_ent_set_disable_time_check(!trusted_clock);
    Serial.printf("[WIFI] enterprise cert time check=%s\n",
                  trusted_clock ? "enabled" : "disabled_until_time_sync");
    const esp_err_t err = esp_wifi_sta_wpa2_ent_enable();
    if (err != ESP_OK) {
      Serial.printf("[WIFI] enterprise enable failed err=%d\n", static_cast<int>(err));
      return false;
    }
    WiFi.begin(settings_.sta_ssid.c_str());
    Serial.printf("[WIFI] STA enterprise begin user=%s\n", settings_.sta_user.c_str());
    return true;
  }

  esp_wifi_sta_wpa2_ent_disable();
  if (mode == "open") {
    WiFi.begin(settings_.sta_ssid.c_str());
    Serial.println("[WIFI] STA open begin");
    return true;
  }
  if (mode == "portal") {
    if (settings_.sta_pass.length() > 0) {
      WiFi.begin(settings_.sta_ssid.c_str(), settings_.sta_pass.c_str());
    } else {
      WiFi.begin(settings_.sta_ssid.c_str());
    }
    Serial.printf("[WIFI] STA portal begin login_url=%s\n", settings_.portal_login_url.c_str());
    return true;
  }
  WiFi.begin(settings_.sta_ssid.c_str(), settings_.sta_pass.c_str());
  Serial.println("[WIFI] STA personal begin");
  return true;
}

bool WifiManager::systemClockTrusted() const {
  return rtc_time_trusted_ || isTrustedEpoch(time(nullptr));
}

void WifiManager::restoreClockFromRtc() {
  time_t rtc_epoch = 0;
  if (!readRx8025Utc(rtc_epoch)) {
    rtc_time_trusted_ = false;
    Serial.println("[RTC] RX8025 read failed or time not trusted");
    return;
  }
  timeval tv {};
  tv.tv_sec = rtc_epoch;
  tv.tv_usec = 0;
  if (settimeofday(&tv, nullptr) != 0) {
    rtc_time_trusted_ = false;
    Serial.println("[RTC] settimeofday failed");
    return;
  }
  rtc_time_trusted_ = true;
  Serial.printf("[RTC] restored UTC epoch=%lu\n", static_cast<unsigned long>(rtc_epoch));
}

void WifiManager::writeClockToRtc(const char *reason) {
  const time_t now_epoch = time(nullptr);
  if (!isTrustedEpoch(now_epoch)) {
    Serial.printf("[RTC] skip write reason=%s untrusted_epoch=%ld\n",
                  reason ? reason : "unknown", static_cast<long>(now_epoch));
    return;
  }
  if (writeRx8025Utc(now_epoch)) {
    rtc_time_trusted_ = true;
    Serial.printf("[RTC] wrote UTC epoch=%lu reason=%s\n",
                  static_cast<unsigned long>(now_epoch),
                  reason ? reason : "unknown");
  } else {
    Serial.printf("[RTC] write failed reason=%s\n", reason ? reason : "unknown");
  }
}

void WifiManager::startSTAWithTimeout(uint32_t connect_timeout_ms, const char *reason_tag) {
  const bool keep_ap = isApSessionActive();
  if (!keep_ap) {
    stop("switch_to_sta");
  } else if (isStaActive()) {
    stopStaOnly("restart_sta_keep_ap");
  }
  digitalWrite(kPeripheralPowerPin, HIGH);
  delay(3);
  WiFi.mode(keep_ap ? WIFI_AP_STA : WIFI_STA);
  WiFi.setSleep(true);
  esp_wifi_set_ps(WIFI_PS_MIN_MODEM);
  WiFi.setHostname(kDefaultHostname);
  if (kDebugLogs) {
    logStaScanResults();
  }
  if (!beginStaConnection()) {
    sta_connect_failed_ = true;
    if (keep_ap) {
      stopStaOnly("sta_auth_config_invalid_keep_ap");
    } else {
      stop("sta_auth_config_invalid");
      auto_exit_requested_ = true;
    }
    return;
  }
  sta_connect_start_ms_ = millis();
  sta_connect_timeout_ms_ = connect_timeout_ms;
  state_ = State::StaConnecting;
  last_sta_wifi_status_ = WiFi.status();
  Serial.printf("[WIFI] STA connecting reason=%s ssid=%s auth=%s user_len=%u pass_len=%u timeout=%lus initial_status=%s/%d\n",
                reason_tag ? reason_tag : "unknown",
                settings_.sta_ssid.c_str(),
                effectiveStaAuthMode().c_str(),
                static_cast<unsigned>(settings_.sta_user.length()),
                static_cast<unsigned>(settings_.sta_pass.length()),
                static_cast<unsigned long>(sta_connect_timeout_ms_ / 1000),
                wifiStatusName(last_sta_wifi_status_),
                last_sta_wifi_status_);
}

void WifiManager::stop(const char *reason) {
  if (state_ != State::Idle) {
    Serial.printf("[WIFI] stop reason=%s\n", reason ? reason : "none");
  }
  stopServer();
  deinitSD();
  MDNS.end();
  const wifi_mode_t current_mode = WiFi.getMode();
  if (current_mode != WIFI_MODE_NULL) {
    if (current_mode == WIFI_MODE_STA || current_mode == WIFI_MODE_APSTA) {
      WiFi.disconnect(false, false);
      delay(60);
    }
    esp_wifi_sta_wpa2_ent_disable();
    esp_wifi_sta_wpa2_ent_clear_identity();
    esp_wifi_sta_wpa2_ent_clear_username();
    esp_wifi_sta_wpa2_ent_clear_password();
    WiFi.mode(WIFI_OFF);
    delay(60);
  }
  digitalWrite(kPeripheralPowerPin, LOW);
  state_ = State::Idle;
  ap_active_ = false;
  sta_connect_start_ms_ = 0;
  sta_connect_timeout_ms_ = 0;
  sta_session_start_ms_ = 0;
  last_activity_ms_ = 0;
  last_calendar_sync_ms_ = 0;
  calendar_sync_pending_ = false;
  last_sta_wifi_status_ = WL_IDLE_STATUS;
}

bool WifiManager::isApSessionActive() const {
  return ap_active_;
}

bool WifiManager::isStaActive() const {
  return state_ == State::StaConnecting || state_ == State::StaRunning;
}

void WifiManager::stopStaOnly(const char *reason) {
  if (!isStaActive()) {
    return;
  }
  Serial.printf("[WIFI] stop STA reason=%s\n", reason ? reason : "none");
  WiFi.disconnect(false, false);
  delay(60);
  esp_wifi_sta_wpa2_ent_disable();
  esp_wifi_sta_wpa2_ent_clear_identity();
  esp_wifi_sta_wpa2_ent_clear_username();
  esp_wifi_sta_wpa2_ent_clear_password();
  state_ = ap_active_ ? State::ApRunning : State::Idle;
  sta_connect_start_ms_ = 0;
  sta_connect_timeout_ms_ = 0;
  sta_session_start_ms_ = 0;
  calendar_sync_pending_ = false;
  last_calendar_sync_ms_ = 0;
  last_sta_wifi_status_ = WL_IDLE_STATUS;
  if (!ap_active_) {
    stop("sta_only_stop_no_ap");
  }
}

bool WifiManager::consumeAutoExitRequested() {
  const bool value = auto_exit_requested_;
  auto_exit_requested_ = false;
  return value;
}

bool WifiManager::consumeSettingsApplyRefreshRequested() {
  const bool value = settings_apply_refresh_pending_;
  settings_apply_refresh_pending_ = false;
  return value;
}

bool WifiManager::consumeStaConnectFailed() {
  const bool value = sta_connect_failed_;
  sta_connect_failed_ = false;
  return value;
}

bool WifiManager::isStaConnecting() const {
  return state_ == State::StaConnecting;
}

bool WifiManager::isStaConnected() const {
  return state_ == State::StaRunning;
}

bool WifiManager::hasStaCredentials() const {
  if (settings_.sta_ssid.length() == 0) {
    return false;
  }
  const String mode = effectiveStaAuthMode();
  if (mode == "open") {
    return true;
  }
  if (mode == "enterprise") {
    return settings_.sta_user.length() > 0 && settings_.sta_pass.length() > 0;
  }
  if (mode == "portal") {
    return true;
  }
  return settings_.sta_pass.length() > 0;
}

bool WifiManager::isCalendarSyncBusy() const {
  return (state_ == State::StaConnecting) ||
         (state_ == State::StaRunning &&
          (calendar_sync_pending_ || last_calendar_sync_status_ == "running"));
}

bool WifiManager::blocksLightSleep() const {
  return state_ != State::Idle ||
         calendar_sync_pending_ ||
         last_calendar_sync_status_ == "running";
}

void WifiManager::requestCalendarSyncNow() {
  calendar_sync_pending_ = true;
  last_calendar_sync_ms_ = 0;
  if (last_calendar_sync_status_ != "running") {
    last_calendar_sync_status_ = "queued";
  }
  last_calendar_sync_error_ = "";
}

bool WifiManager::syncWeatherNow(const char *reason) {
  if (state_ != State::StaRunning || WiFi.status() != WL_CONNECTED) {
    Serial.printf("[WEATHER] sync skipped reason=%s sta_not_connected\n",
                  reason ? reason : "manual");
    return false;
  }
  String resolved_timezone;
  bool timezone_updated = false;
  String local_time;
  String time_sync_error;
  String preview;
  int http_status = 0;
  String request_error;
  const bool ok = syncClockFromWeather(resolved_timezone, timezone_updated, local_time,
                                       time_sync_error, preview, http_status, request_error);
  if (ok) {
    writeClockToRtc(reason ? reason : "weather_sync");
    Serial.printf("[WEATHER] sync ok reason=%s code=%d city=%s\n",
                  reason ? reason : "manual", weather_code_, settings_.weather_city.c_str());
  } else {
    Serial.printf("[WEATHER] sync failed reason=%s status=%d err=%s code=%d\n",
                  reason ? reason : "manual", http_status, request_error.c_str(), weather_code_);
  }
  return ok;
}

const WifiManager::Settings &WifiManager::settings() const {
  return settings_;
}

bool WifiManager::syncClockFromWeather(String &resolved_timezone, bool &timezone_updated,
                                       String &local_time, String &time_sync_error, String &preview,
                                       int &http_status, String &request_error) {
  resolved_timezone = "";
  timezone_updated = false;
  local_time = "";
  time_sync_error = "";
  preview = "";
  http_status = 0;
  request_error = "";

  if (!(settings_.weather_url.startsWith("http://") || settings_.weather_url.startsWith("https://"))) {
    request_error = "bad_weather_url";
    return false;
  }

  HTTPClient http;
  http.setConnectTimeout(8000);
  http.setTimeout(8000);
  if (!http.begin(settings_.weather_url)) {
    request_error = "http_begin_failed";
    return false;
  }

  http_status = http.GET();
  if (http_status <= 0) {
    http.end();
    request_error = "weather_request_failed";
    return false;
  }

  String body = http.getString();
  http.end();

  preview = body;
  preview.replace("\r", " ");
  preview.replace("\n", " ");
  if (preview.length() > 240) {
    preview = preview.substring(0, 240);
  }

  resolved_timezone = extractJsonStringField(body, "timezone");
  int32_t utc_offset_seconds = 0;
  const bool has_utc_offset = extractJsonIntField(body, "utc_offset_seconds", utc_offset_seconds);
  int32_t weather_code = -1;
  if (extractJsonIntField(body, "weather_code", weather_code)) {
    weather_code_ = static_cast<int>(weather_code);
    Serial.printf("[WEATHER] code=%d\n", weather_code_);
  } else {
    weather_code_ = -1;
    Serial.println("[WEATHER] code missing");
  }
  if (resolved_timezone.length() == 0) {
    resolved_timezone = settings_.timezone;
  }
  const String tz_for_sync = timezoneForEsp(resolved_timezone, has_utc_offset, utc_offset_seconds);

  if (resolved_timezone.length() > 0 && resolved_timezone != settings_.timezone) {
    settings_.timezone = resolved_timezone;
    saveSettings();
    timezone_updated = true;
    Serial.printf("[TIME] timezone updated from weather: %s\n", settings_.timezone.c_str());
  }

  if (!syncClockWithTimezone(tz_for_sync, local_time, time_sync_error)) {
    return false;
  }
  return true;
}

size_t WifiManager::calendarEventCount() const {
  return calendar_store_.count();
}

bool WifiManager::calendarEventAt(size_t index, CalendarEvent &event) const {
  return calendar_store_.eventAt(index, event);
}

size_t WifiManager::calendarMonthSummaryCount() const {
  return calendar_month_summary_count_;
}

bool WifiManager::calendarMonthSummaryAt(size_t index, CalendarMonthSummaryEvent &event) const {
  if (index >= calendar_month_summary_count_) {
    return false;
  }
  event = calendar_month_summaries_[index];
  return true;
}

uint32_t WifiManager::calendarMonthSummarySignature() const {
  return calendar_month_summary_signature_;
}

void WifiManager::loadSettings() {
  if (prefs_ == nullptr) {
    prefs_ = new Preferences();
  }
  String packed_events;
  uint16_t next_calendar_event_id = calendar_store_.nextId();
  if (!SettingsStore::load(*prefs_, settings_, next_calendar_event_id, packed_events)) {
    applyDefaultSettings();
    return;
  }
  calendar_store_.setNextId(next_calendar_event_id);
  calendar_store_.deserialize(packed_events);
  calendar_store_.setNextId(next_calendar_event_id);
  Serial.printf("[CFG] loaded sta_ssid=%s (%s)\n",
                settings_.sta_ssid.c_str(),
                (settings_.sta_ssid == SettingsStore::defaultStaSsid()) ? "default" : "prefs");
}

bool WifiManager::saveSettings() {
  if (prefs_ == nullptr) {
    prefs_ = new Preferences();
  }
  if (!SettingsStore::save(*prefs_, settings_, calendar_store_.nextId(), calendar_store_.serialize())) {
    Serial.println("[CFG] preferences open failed");
    return false;
  }
  Serial.println("[CFG] settings saved");
  return true;
}

void WifiManager::pruneExpiredCalendarEvents() {
  const time_t now_epoch = time(nullptr);
  if (now_epoch <= 0) {
    return;
  }
  const time_t month_start = localMonthWindowStart(now_epoch);
  const time_t month_end = localWindowEndOneMonth(month_start);
  struct tm start_tm {};
  struct tm end_tm {};
  if (localtime_r(&month_start, &start_tm) == nullptr ||
      localtime_r(&month_end, &end_tm) == nullptr) {
    return;
  }
  const String min_date = formatDateYmd(start_tm);
  const String max_date = formatDateYmd(end_tm);
  const size_t removed = calendar_store_.removeOnceOutsideRange(min_date, max_date);
  if (removed > 0) {
    Serial.printf("[CAL] pruned out-of-month manual events removed=%u range=%s..%s\n",
                  static_cast<unsigned>(removed), min_date.c_str(), max_date.c_str());
    saveSettings();
  }
}

void WifiManager::applyDefaultSettings() {
  size_t ignored_count = 0;
  uint16_t next_calendar_event_id = calendar_store_.nextId();
  SettingsStore::applyDefaults(settings_, ignored_count, next_calendar_event_id);
  calendar_store_.clear();
  calendar_store_.setNextId(next_calendar_event_id);
}

void WifiManager::maybeSyncCalendarUrl(uint32_t now_ms) {
  if (state_ != State::StaRunning || WiFi.status() != WL_CONNECTED) {
    return;
  }
  if (!settings_.calendar_enabled) {
    return;
  }
  const bool is_remote_url =
      settings_.calendar_url.startsWith("http://") || settings_.calendar_url.startsWith("https://");
  const bool is_local_path = settings_.calendar_url.startsWith("/");
  if (!is_remote_url && !is_local_path) {
    Serial.printf("[CALSYNC] skip unsupported source=%s\n", settings_.calendar_url.c_str());
    calendar_sync_pending_ = false;
    if (last_calendar_sync_status_ == "queued" || last_calendar_sync_status_ == "running") {
      last_calendar_sync_status_ = "idle";
    }
    return;
  }

  const uint32_t requested_interval_ms =
      (settings_.calendar_refresh_sec > 0u) ? settings_.calendar_refresh_sec * 1000u : 0u;
  const uint32_t sync_interval_ms =
      std::max<uint32_t>(requested_interval_ms, kCalendarSyncMinIntervalMs);
  const bool due_by_interval =
      last_calendar_sync_ms_ != 0u && (now_ms - last_calendar_sync_ms_) >= sync_interval_ms;
  if (!calendar_sync_pending_ && !due_by_interval) {
    return;
  }

  Serial.printf("[CALSYNC] trigger pending=%s due=%s interval_s=%lu now_ms=%lu url=%s\n",
                calendar_sync_pending_ ? "true" : "false",
                due_by_interval ? "true" : "false",
                static_cast<unsigned long>(sync_interval_ms / 1000u),
                static_cast<unsigned long>(now_ms),
                settings_.calendar_url.c_str());

  calendar_sync_pending_ = false;
  last_calendar_sync_ms_ = now_ms;
  last_calendar_sync_status_ = "running";
  last_calendar_sync_error_ = "";
  String error_msg;
  if (!syncCalendarFromUrl(error_msg)) {
    last_calendar_sync_status_ = "error";
    last_calendar_sync_error_ = error_msg;
    Serial.printf("[CALSYNC] failed err=%s url=%s\n", error_msg.c_str(),
                  settings_.calendar_url.c_str());
  }
}

bool WifiManager::syncCalendarFromUrl(String &error_msg) {
  error_msg = "";
  last_calendar_sync_imported_ = 0;
  last_calendar_sync_total_ = 0;
  last_calendar_sync_vevents_ = 0;

  const uint32_t sync_start_ms = millis();
  if (kDebugLogs) {
    Serial.printf("[CALSYNC] fetch begin url=%s free_heap=%u largest=%u\n",
                  settings_.calendar_url.c_str(),
                  static_cast<unsigned>(ESP.getFreeHeap()),
                  static_cast<unsigned>(ESP.getMaxAllocHeap()));
  }

  String body;
  String content_type = "text/calendar";
  if (settings_.calendar_url.startsWith("/")) {
    initWebFs();
    if (!web_fs_ready_) {
      error_msg = "spiffs_not_ready";
      Serial.printf("[CALSYNC] local open failed err=%s path=%s\n", error_msg.c_str(),
                    settings_.calendar_url.c_str());
      return false;
    }
    File file = SPIFFS.open(settings_.calendar_url, FILE_READ);
    if (!file) {
      error_msg = "spiffs_open_failed";
      Serial.printf("[CALSYNC] local open failed err=%s path=%s\n", error_msg.c_str(),
                    settings_.calendar_url.c_str());
      return false;
    }
    body = file.readString();
    file.close();
    if (kDebugLogs) {
      Serial.printf("[CALSYNC] local load ok path=%s bytes=%u elapsed=%lums\n",
                    settings_.calendar_url.c_str(),
                    static_cast<unsigned>(body.length()),
                    static_cast<unsigned long>(millis() - sync_start_ms));
    }
  } else {
    HTTPClient http;
    http.setConnectTimeout(8000);
    http.setTimeout(8000);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    if (!http.begin(settings_.calendar_url)) {
      error_msg = "http_begin_failed";
      return false;
    }

    const int http_code = http.GET();
    if (http_code != 200) {
      error_msg = "http_" + String(http_code);
      Serial.printf("[CALSYNC] fetch http_failed code=%d elapsed=%lums\n", http_code,
                    static_cast<unsigned long>(millis() - sync_start_ms));
      http.end();
      return false;
    }

    content_type = http.header("Content-Type");
    body = http.getString();
    http.end();
    if (kDebugLogs) {
      Serial.printf("[CALSYNC] fetch ok code=%d bytes=%u content_type=%s elapsed=%lums\n",
                    http_code, static_cast<unsigned>(body.length()), content_type.c_str(),
                    static_cast<unsigned long>(millis() - sync_start_ms));
    }
  }
  if (body.length() == 0) {
    error_msg = "empty_body";
    return false;
  }
  if (body.indexOf("BEGIN:VCALENDAR") < 0) {
    error_msg = "not_ics";
    return false;
  }

  std::vector<ParsedIcsEvent> master_events;
  std::vector<ParsedIcsEvent> override_events;
  size_t vevent_count = 0;
  parseIcsBodyIntoEvents(body, master_events, override_events, vevent_count);
  last_calendar_sync_vevents_ = static_cast<uint16_t>(std::min<size_t>(vevent_count, 65535u));
  if (kDebugLogs) {
    Serial.printf("[CALSYNC] parse vevents=%u masters=%u overrides=%u\n",
                  static_cast<unsigned>(vevent_count),
                  static_cast<unsigned>(master_events.size()),
                  static_cast<unsigned>(override_events.size()));
  }
  if (vevent_count == 0u) {
    error_msg = "no_vevent";
    return false;
  }

  const time_t now_epoch = time(nullptr);
  if (now_epoch <= 0) {
    error_msg = "clock_invalid";
    return false;
  }
  const time_t window_start = localMonthWindowStart(now_epoch);
  const time_t window_end = localWindowEndOneMonth(window_start);
  if (kDebugLogs) {
    Serial.printf("[CALSYNC] window start=%s end=%s now=%s\n",
                  formatDateTimeYmdHm(window_start).c_str(),
                  formatDateTimeYmdHm(window_end).c_str(),
                  formatDateTimeYmdHm(now_epoch).c_str());
  }

  std::vector<IcsOverride> override_metadata;
  collectOverrideMetadata(override_events, override_metadata);
  if (kDebugLogs) {
    Serial.printf("[CALSYNC] override metadata entries=%u\n",
                  static_cast<unsigned>(override_metadata.size()));
  }

  std::vector<ImportedCalendarEvent> imported_items;
  imported_items.reserve(master_events.size() + override_events.size());

  for (const ParsedIcsEvent &event : master_events) {
    if (event.rrule.length() == 0) {
      expandSingleEvent(event, window_start, window_end, imported_items);
      continue;
    }

    CalendarRruleCore rrule;
    if (!parseRruleCore(event.rrule, rrule)) {
      expandSingleEvent(event, window_start, window_end, imported_items);
      continue;
    }
    expandRecurringEvent(event, rrule, override_metadata, window_start, window_end, imported_items);
  }

  appendOverrideEvents(override_events, window_start, window_end, imported_items);
  sortImportedEvents(imported_items);
  last_calendar_sync_imported_ =
      static_cast<uint16_t>(std::min<size_t>(imported_items.size(), 65535u));
  Serial.printf("[CALSYNC] expanded imported=%u\n",
                static_cast<unsigned>(imported_items.size()));
  if (kDebugLogs) {
    for (size_t i = 0; i < imported_items.size() && i < 8; ++i) {
      const CalendarEvent &event = imported_items[i].event;
      Serial.printf("[CALSYNC] item[%u] date=%s time=%s end=%s title=%s source=%s external=%s\n",
                    static_cast<unsigned>(i),
                    event.date.c_str(),
                    event.time_hhmm.c_str(),
                    event.end_time_hhmm.c_str(),
                    event.title.c_str(),
                    event.source.c_str(),
                    event.external_id.c_str());
    }
    if (imported_items.size() > 8u) {
      Serial.printf("[CALSYNC] item listing truncated remaining=%u\n",
                    static_cast<unsigned>(imported_items.size() - 8u));
    }
  }

  calendar_month_summary_count_ = 0;
  uint32_t month_signature = 2166136261UL;
  for (const ImportedCalendarEvent &item : imported_items) {
    if (calendar_month_summary_count_ >= static_cast<size_t>(kMaxCalendarMonthSummaries)) {
      break;
    }
    CalendarMonthSummaryEvent &summary = calendar_month_summaries_[calendar_month_summary_count_++];
    summary.title = item.event.title;
    summary.date = item.event.date;
    summary.time_hhmm = item.event.time_hhmm;
    summary.end_time_hhmm = item.event.end_time_hhmm;
    summary.color = item.event.color;
    mixCalendarHashString(month_signature, summary.date);
    mixCalendarHashString(month_signature, summary.time_hhmm);
    mixCalendarHashString(month_signature, summary.end_time_hhmm);
    mixCalendarHashString(month_signature, summary.color);
    mixCalendarHashString(month_signature, summary.title);
  }
  mixCalendarHashInt(month_signature, static_cast<uint32_t>(calendar_month_summary_count_));
  calendar_month_summary_signature_ = month_signature;

  const std::vector<CalendarEvent> normalized_imported;
  const CalendarSyncMergeStats merge_stats =
      CalendarSyncService::mergeImportedEvents(calendar_store_, normalized_imported);
  last_calendar_sync_epoch_ = time(nullptr);
  last_calendar_sync_status_ = "ok";
  last_calendar_sync_error_ = "";
  last_calendar_sync_total_ =
      static_cast<uint16_t>(std::min<size_t>(calendar_store_.count(), 65535u));
  saveSettings();
  Serial.printf("[CALSYNC] ok vevents=%u imported=%u month=%u stored_ics=%u kept_manual=%u total=%u elapsed=%lums window=%lu..%lu\n",
                static_cast<unsigned>(vevent_count),
                static_cast<unsigned>(imported_items.size()),
                static_cast<unsigned>(calendar_month_summary_count_),
                static_cast<unsigned>(0),
                static_cast<unsigned>(merge_stats.kept_manual),
                static_cast<unsigned>(calendar_store_.count()),
                static_cast<unsigned long>(millis() - sync_start_ms),
                static_cast<unsigned long>(window_start),
                static_cast<unsigned long>(window_end));
  return true;
}

void WifiManager::startServer() {
  stopServer();
  server_ = new WebServer(kHttpPort);

  server_->on("/", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/generate_204", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/hotspot-detect.html", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/connecttest.txt", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/ncsi.txt", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/redirect", HTTP_GET, [this]() { handleRoot(); });
  server_->on("/app.js", HTTP_GET, [this]() {
    markActivity(millis());
    if (serveWebAsset("/app.js", "application/javascript; charset=utf-8")) {
      return;
    }
    server_->send(404, "application/json", "{\"ok\":false,\"error\":\"not_found\"}");
  });
  server_->on("/favicon.ico", HTTP_ANY, [this]() {
    markActivity(millis());
    server_->send(204, "text/plain", "");
  });
  server_->on("/api/status", HTTP_GET, [this]() { handleStatus(); });
  server_->on("/api/settings", HTTP_GET, [this]() { handleSettingsGet(); });
  server_->on("/api/settings", HTTP_POST, [this]() { handleSettingsPost(); });
  server_->on("/api/calendar/events", HTTP_GET, [this]() { handleCalendarEventsGet(); });
  server_->on("/api/calendar/events", HTTP_POST, [this]() { handleCalendarEventsPost(); });
  server_->on("/api/calendar/events", HTTP_DELETE, [this]() { handleCalendarEventsDelete(); });
  server_->on("/api/geocode", HTTP_GET, [this]() { handleGeocode(); });
  server_->on("/api/files", HTTP_GET, [this]() { handleFilesList(); });
  server_->on("/api/dir", HTTP_POST, [this]() { handleDirCreate(); });
  server_->on("/api/file", HTTP_GET, [this]() { handleFileDownload(); });
  server_->on("/api/file", HTTP_DELETE, [this]() { handleFileDelete(); });
  server_->on("/api/weather_test", HTTP_GET, [this]() { handleWeatherTest(); });
  server_->on("/api/stop", HTTP_POST, [this]() { handleStopPortal(); });
  server_->on("/api/reboot", HTTP_POST, [this]() { handleReboot(); });
  server_->on(
      "/api/upload", HTTP_POST,
      [this]() {
        markActivity(millis());
        if (upload_ok_) {
          server_->send(200, "application/json", "{\"ok\":true}");
          return;
        }
        String json = "{\"ok\":false,\"error\":\"";
        json += jsonEscape(upload_error_);
        json += "\"}";
        server_->send(500, "application/json", json);
      },
      [this]() { handleFileUpload(); });
  server_->onNotFound([this]() { handleNotFound(); });
  server_->begin();
  Serial.println("[WIFI] web server started");
}

void WifiManager::stopServer() {
  if (server_ == nullptr) {
    return;
  }
  server_->stop();
  delete server_;
  server_ = nullptr;
}

void WifiManager::updateTimeout(uint32_t now_ms) {
  if (isApSessionActive()) {
    if (last_activity_ms_ == 0) {
      markActivity(now_ms);
      return;
    }
    // Keep AP alive while at least one station is connected.
    const int sta_num = WiFi.softAPgetStationNum();
    if (sta_num > 0) {
      markActivity(now_ms);
    }
    const uint32_t idle_ms = now_ms - last_activity_ms_;
    if (idle_ms >= kApIdleTimeoutMs) {
      Serial.printf("[WIFI] AP idle timeout -> stop (idle_ms=%lu, sta_num=%d)\n",
                    static_cast<unsigned long>(idle_ms), sta_num);
      stop("ap_idle_timeout");
      auto_exit_requested_ = true;
    }
    return;
  }
  if (state_ == State::StaRunning) {
    if (kStaSessionTimeoutMs == 0) {
      return;
    }
    const uint32_t base_ms =
        (last_activity_ms_ >= sta_session_start_ms_) ? last_activity_ms_ : sta_session_start_ms_;
    if (base_ms == 0) {
      sta_session_start_ms_ = now_ms;
      markActivity(now_ms);
      Serial.printf("[WIFI] STA idle baseline reset now=%lu\n",
                    static_cast<unsigned long>(now_ms));
      return;
    }
    const uint32_t idle_ms = now_ms - base_ms;
    if (idle_ms >= kStaSessionTimeoutMs) {
      Serial.printf("[WIFI] STA idle timeout -> stop (idle_ms=%lu base_ms=%lu now_ms=%lu last_activity_ms=%lu session_start_ms=%lu)\n",
                    static_cast<unsigned long>(idle_ms),
                    static_cast<unsigned long>(base_ms),
                    static_cast<unsigned long>(now_ms),
                    static_cast<unsigned long>(last_activity_ms_),
                    static_cast<unsigned long>(sta_session_start_ms_));
      stop("sta_idle_timeout");
      auto_exit_requested_ = true;
    }
  }
}

void WifiManager::markActivity(uint32_t now_ms) {
  last_activity_ms_ = now_ms;
}

void WifiManager::initSD() {
  sd_ready_ = mountSdCard("wifi_manager");
}

void WifiManager::deinitSD() {
  if (sd_ready_) {
    unmountSdCard("wifi_manager");
    sd_ready_ = false;
  }
}

void WifiManager::initWebFs() {
  if (web_fs_ready_) {
    return;
  }
  web_fs_ready_ = SPIFFS.begin(false);
  Serial.printf("[WEB] SPIFFS init %s\n", web_fs_ready_ ? "ok" : "failed");
}

bool WifiManager::serveWebAsset(const char *path, const char *content_type) {
  if (server_ == nullptr || path == nullptr || content_type == nullptr) {
    return false;
  }
  initWebFs();
  if (!web_fs_ready_) {
    return false;
  }
  File file = SPIFFS.open(path, FILE_READ);
  if (!file) {
    return false;
  }
  server_->sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  server_->sendHeader("Pragma", "no-cache");
  server_->streamFile(file, content_type);
  file.close();
  return true;
}

String WifiManager::listDirectoryJson(const char *path) {
  if (!sd_ready_) {
    return "{\"ok\":false,\"error\":\"sd_not_ready\"}";
  }

  File dir = SD.open(path);
  if (!dir || !dir.isDirectory()) {
    return "{\"ok\":false,\"error\":\"invalid_path\"}";
  }

  String out = "{\"ok\":true,\"path\":\"";
  out += jsonEscape(path);
  out += "\",\"items\":[";
  uint32_t skipped = 0;
  bool first = true;
  File entry = dir.openNextFile();
  while (entry) {
    const String name = String(entry.name());
    if (String(path) == "/pic" && !entry.isDirectory() && !isEpd4Path(name)) {
      ++skipped;
      entry = dir.openNextFile();
      continue;
    }
    if (!first) {
      out += ",";
    }
    first = false;
    out += "{\"name\":\"";
    out += jsonEscape(name);
    out += "\",\"dir\":";
    out += entry.isDirectory() ? "true" : "false";
    out += ",\"size\":";
    out += String(static_cast<uint32_t>(entry.size()));
    out += "}";
    entry = dir.openNextFile();
  }
  out += "],\"skipped\":";
  out += String(skipped);
  out += "}";
  Serial.printf("[SD] list path=%s items_done skipped=%lu\n", path,
                static_cast<unsigned long>(skipped));
  return out;
}

String WifiManager::contentTypeForPath(const String &path) const {
  if (path.endsWith(".html")) return "text/html";
  if (path.endsWith(".css")) return "text/css";
  if (path.endsWith(".js")) return "application/javascript";
  if (path.endsWith(".json")) return "application/json";
  if (path.endsWith(".png")) return "image/png";
  if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
  if (path.endsWith(".bmp")) return "image/bmp";
  return "application/octet-stream";
}

bool WifiManager::isSafePath(const String &path) const {
  if (path.length() == 0 || path[0] != '/') {
    return false;
  }
  if (path.indexOf("..") >= 0 || path.indexOf('\\') >= 0) {
    return false;
  }
  return true;
}

bool WifiManager::isEpd4Path(const String &path) const {
  String lower = path;
  lower.toLowerCase();
  return lower.endsWith(".epd4");
}

bool WifiManager::removePathRecursive(const String &path) const {
  File entry = SD.open(path);
  if (!entry) {
    return false;
  }
  if (!entry.isDirectory()) {
    entry.close();
    return SD.remove(path);
  }

  File child = entry.openNextFile();
  while (child) {
    const String child_name = String(child.name());
    const bool child_is_dir = child.isDirectory();
    child.close();
    if (!removePathRecursive(child_name)) {
      entry.close();
      return false;
    }
    child = entry.openNextFile();
  }
  entry.close();
  return SD.rmdir(path);
}

String WifiManager::currentIp() const {
  if (state_ == State::ApRunning) {
    return WiFi.softAPIP().toString();
  }
  return WiFi.localIP().toString();
}

void WifiManager::initSensors() {
  digitalWrite(kPeripheralPowerPin, HIGH);
  delay(3);
  Wire.begin(kI2cSdaPin, kI2cSclPin);
  restoreClockFromRtc();
  battery_adc_pin_ = 39;  // User-requested trial pin.
  pinMode(battery_adc_pin_, INPUT);
  analogSetPinAttenuation(static_cast<uint8_t>(battery_adc_pin_), ADC_11db);
  analogReadResolution(12);
  battery_mv_ = readBatteryMilliVolts(battery_adc_pin_);
  last_sensor_poll_ms_ = millis();
  Serial.printf("[SENSOR] battery adc pin=%d mv=%d\n", battery_adc_pin_, battery_mv_);
}

void WifiManager::updateSensors(uint32_t now_ms) {
  if ((now_ms - last_sensor_poll_ms_) < kSensorPollIntervalMs) {
    return;
  }
  last_sensor_poll_ms_ = now_ms;
  if (battery_adc_pin_ >= 0) {
    battery_mv_ = readBatteryMilliVolts(battery_adc_pin_);
  }
}

void WifiManager::sampleSensorsNow(bool assume_peripheral_powered) {
  const int previous_power_state = digitalRead(kPeripheralPowerPin);
  const bool restore_power =
      !assume_peripheral_powered && previous_power_state != HIGH;
  if (restore_power) {
    pinMode(kPeripheralPowerPin, OUTPUT);
    digitalWrite(kPeripheralPowerPin, HIGH);
    delay(3);
  }
  if (battery_adc_pin_ >= 0) {
    battery_mv_ = readBatteryMilliVolts(battery_adc_pin_);
  }
  float temperature_c = NAN;
  float humidity_pct = NAN;
  if (readAHT20(temperature_c, humidity_pct)) {
    temperature_c_ = temperature_c;
    humidity_pct_ = humidity_pct;
  } else {
    temperature_c_ = NAN;
    humidity_pct_ = NAN;
  }
  if (restore_power) {
    digitalWrite(kPeripheralPowerPin, LOW);
  }
}

bool WifiManager::readAHT20(float &temperature_c, float &humidity_pct) {
  auto readStatus = []() -> int {
    Wire.beginTransmission(kAht20Address);
    Wire.write(0x71);
    if (Wire.endTransmission(false) != 0) {
      return -1;
    }
    const int n = Wire.requestFrom(static_cast<int>(kAht20Address), 1);
    if (n != 1 || !Wire.available()) {
      return -1;
    }
    return Wire.read();
  };

  int status = readStatus();
  if (status < 0) {
    aht_ready_ = false;
    return false;
  }

  if ((status & 0x08) == 0) {
    Wire.beginTransmission(kAht20Address);
    Wire.write(0xBE);
    Wire.write(0x08);
    Wire.write(0x00);
    if (Wire.endTransmission() != 0) {
      aht_ready_ = false;
      return false;
    }
    delay(10);
    status = readStatus();
    if (status < 0 || (status & 0x08) == 0) {
      aht_ready_ = false;
      return false;
    }
  }

  Wire.beginTransmission(kAht20Address);
  Wire.write(0xAC);
  Wire.write(0x33);
  Wire.write(0x00);
  if (Wire.endTransmission() != 0) {
    aht_ready_ = false;
    return false;
  }

  delay(85);
  status = readStatus();
  if (status < 0 || (status & 0x80) != 0) {
    aht_ready_ = false;
    return false;
  }

  const int len = Wire.requestFrom(static_cast<int>(kAht20Address), 6);
  if (len != 6) {
    aht_ready_ = false;
    return false;
  }
  uint8_t data[6] = {0};
  for (int i = 0; i < 6; ++i) {
    if (!Wire.available()) {
      aht_ready_ = false;
      return false;
    }
    data[i] = static_cast<uint8_t>(Wire.read());
  }

  const uint32_t raw_humidity =
      (static_cast<uint32_t>(data[1]) << 12) |
      (static_cast<uint32_t>(data[2]) << 4) |
      (static_cast<uint32_t>(data[3]) >> 4);
  const uint32_t raw_temperature =
      ((static_cast<uint32_t>(data[3]) & 0x0F) << 16) |
      (static_cast<uint32_t>(data[4]) << 8) |
      static_cast<uint32_t>(data[5]);

  humidity_pct = (static_cast<float>(raw_humidity) * 100.0f) / 1048576.0f;
  temperature_c = (static_cast<float>(raw_temperature) * 200.0f) / 1048576.0f - 50.0f;
  aht_ready_ = true;
  return true;
}

int WifiManager::readBatteryMilliVolts(int pin) const {
  static constexpr uint8_t kSampleCount = 9;
  int samples[kSampleCount] = {};
  uint8_t valid_count = 0;
  for (uint8_t i = 0; i < kSampleCount; ++i) {
    const int raw_mv = analogReadMilliVolts(static_cast<uint8_t>(pin));
    if (raw_mv > 0) {
      samples[valid_count++] = raw_mv;
    }
    delay(2);
  }
  if (valid_count == 0) {
    return -1;
  }
  for (uint8_t i = 1; i < valid_count; ++i) {
    const int value = samples[i];
    uint8_t j = i;
    while (j > 0 && samples[j - 1] > value) {
      samples[j] = samples[j - 1];
      --j;
    }
    samples[j] = value;
  }
  const int raw_mv = samples[valid_count / 2u];
  // Hardware divider is 1:2 at IO39, so the ADC sees half of VBAT.
  return raw_mv * 2;
}

void WifiManager::detectBatteryPin() {}

float WifiManager::estimateBatteryPercent(int battery_mv) const {
  if (battery_mv <= 0) {
    return -1.0f;
  }
  constexpr float kMinMv = 3300.0f;
  constexpr float kMaxMv = 4200.0f;
  float pct = (static_cast<float>(battery_mv) - kMinMv) * 100.0f / (kMaxMv - kMinMv);
  if (pct < 0.0f) pct = 0.0f;
  if (pct > 100.0f) pct = 100.0f;
  return pct;
}

void WifiManager::handleRoot() {
  markActivity(millis());
  const String mode = (state_ == State::ApRunning)
                          ? "AP"
                          : ((state_ == State::StaRunning) ? "STA" : "IDLE");
  if (kDebugLogs) {
    Serial.printf("[HTTP] GET / from %s mode=%s\n",
                  server_->client().remoteIP().toString().c_str(), mode.c_str());
  }
  if (serveWebAsset(kPortalHtmlPath, "text/html; charset=utf-8")) {
    return;
  }
  if (web_fs_ready_) {
    Serial.println("[WEB] missing /portal.html in SPIFFS, falling back to minimal page");
  } else {
    Serial.println("[WEB] SPIFFS not ready, falling back to minimal page");
  }
  const char *fallback =
      "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' "
      "content='width=device-width,initial-scale=1'><title>Portal Missing</title></head>"
      "<body style='font-family:sans-serif;padding:16px'>"
      "<h3>Portal page missing</h3>"
      "<p>SPIFFS file not found: /portal.html</p>"
      "<p>Please upload filesystem assets (uploadfs), then refresh.</p>"
      "</body></html>";
  server_->send(200, "text/html; charset=utf-8", fallback);
  return;
  String html;
  html.reserve(18000);
  html += R"HTML(
<!doctype html>
<html>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width,initial-scale=1'>
  <title>E-paper 管理台</title>
  <style>
    :root {
      --bg1:#eef3f8;
      --bg2:#f7f9fc;
      --card:#ffffffd9;
      --line:#d7dee7;
      --text:#1f2a36;
      --muted:#5d6b79;
      --accent:#0f7ae5;
      --accent2:#2aa3f7;
      --danger:#df4d4d;
      --shadow:0 10px 24px rgba(17,34,68,.08);
      --soft:#eef5fc;
    }
    * { box-sizing: border-box; }
    body {
      margin:0;
      font-family:"Noto Sans SC","Source Han Sans SC","PingFang SC","Microsoft YaHei",sans-serif;
      background:
        radial-gradient(1200px 500px at -10% -20%, #d5e7ff 0%, transparent 60%),
        radial-gradient(1000px 600px at 110% -10%, #d8f1ff 0%, transparent 60%),
        linear-gradient(180deg,var(--bg1),var(--bg2));
      color:var(--text);
      min-height:100vh;
    }
    .wrap { max-width: 980px; margin: 20px auto; padding: 0 12px; }
    .top {
      background:var(--card);
      border:1px solid var(--line);
      border-radius:14px;
      padding:14px;
      margin-bottom:12px;
      backdrop-filter: blur(3px);
      box-shadow: var(--shadow);
    }
    .title { font-size:24px; font-weight:700; margin-bottom:6px; letter-spacing:.3px; }
    .meta { color:var(--muted); font-size:14px; }
    .tabs { display:flex; gap:8px; margin-top:10px; }
    .tab-btn {
      border:1px solid var(--line);
      background:#fff;
      color:var(--text);
      padding:8px 13px;
      border-radius:10px;
      cursor:pointer;
      transition:.2s ease;
    }
    .tab-btn:hover { transform: translateY(-1px); border-color:#b9c7d6; }
    .tab-btn.active {
      background: linear-gradient(135deg,var(--accent),var(--accent2));
      color:#fff;
      border-color:transparent;
      box-shadow: 0 4px 12px rgba(15,122,229,.28);
    }
    .card {
      background:var(--card);
      border:1px solid var(--line);
      border-radius:14px;
      padding:14px;
      margin-bottom:12px;
      backdrop-filter: blur(3px);
      box-shadow: var(--shadow);
    }
    .tab-panel { display:none; }
    .tab-panel.active { display:block; }
    .grid2 { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    .field label { display:block; font-size:13px; color:var(--muted); margin-bottom:4px; }
    .field input {
      width:100%;
      padding:9px 10px;
      border:1px solid var(--line);
      border-radius:10px;
      background:#fff;
      transition:.2s ease;
    }
    .field input:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px rgba(15,122,229,.12); }
    .btn {
      padding:8px 12px;
      border:1px solid var(--line);
      border-radius:10px;
      background:#fff;
      cursor:pointer;
      transition:.2s ease;
    }
    .btn:hover { transform: translateY(-1px); }
    .btn.primary { background: linear-gradient(135deg,var(--accent),var(--accent2)); color:#fff; border-color:transparent; }
    .btn.warn { background: var(--danger); color:#fff; border-color:var(--danger); }
    .row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
    pre {
      margin:0;
      padding:10px;
      background:#f5f7fa;
      border:1px solid var(--line);
      border-radius:10px;
      overflow:auto;
      line-height:1.45;
    }
    table { width:100%; border-collapse:collapse; margin-top:8px; }
    th,td { padding:8px; border-bottom:1px solid var(--line); text-align:left; font-size:14px; }
    th { color:var(--muted); font-weight:600; }
    .small { font-size:12px; color:#6b7785; }
    .status-grid { display:grid; grid-template-columns:repeat(2,minmax(220px,1fr)); gap:10px; margin-top:10px; }
    .status-item { border:1px solid var(--line); border-radius:10px; background:#f7f9fc; padding:10px; }
    .status-item .k { font-size:12px; color:var(--muted); margin-bottom:4px; }
    .status-item .v { font-size:16px; font-weight:600; color:var(--text); }
    .notice {
      margin-top:10px;
      padding:10px 12px;
      border:1px solid #cfe0f3;
      background:#f3f8fe;
      border-radius:10px;
      color:#37516d;
      white-space:pre-wrap;
      display:none;
    }
    .path-bar {
      display:flex;
      gap:8px;
      align-items:center;
      justify-content:space-between;
      flex-wrap:wrap;
      margin-bottom:10px;
    }
    .path-tools { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
    .crumbs { display:flex; gap:6px; align-items:center; flex-wrap:wrap; margin-bottom:10px; }
    .crumb {
      border:1px solid var(--line);
      background:var(--soft);
      color:var(--text);
      padding:6px 10px;
      border-radius:999px;
      cursor:pointer;
    }
    .crumb.current { background:#fff; font-weight:600; }
    .quick-links { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px; }
    .file-table td.actions { width:220px; }
    .name-btn {
      border:none;
      background:none;
      color:var(--text);
      cursor:pointer;
      padding:0;
      font:inherit;
      text-align:left;
    }
    .name-btn.dir { color:var(--accent); font-weight:600; }
    .badge {
      display:inline-block;
      min-width:56px;
      padding:4px 8px;
      border-radius:999px;
      background:#eef4fb;
      color:#46627f;
      font-size:12px;
      text-align:center;
    }
    .badge.dir { background:#dff0ff; color:#185b91; }
    .upload-extra {
      margin-top:10px;
      padding:12px;
      border:1px solid var(--line);
      border-radius:12px;
      background:#f8fbff;
      display:none;
    }
    .upload-extra.show { display:block; }
    .hint-line { margin-top:8px; font-size:12px; color:#617180; line-height:1.6; }
    .tooltip {
      position:relative;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      width:18px;
      height:18px;
      border-radius:50%;
      border:1px solid #b9c7d6;
      color:#4c6075;
      font-size:12px;
      cursor:help;
      background:#fff;
    }
    .tooltip .tip {
      position:absolute;
      left:50%;
      bottom:calc(100% + 8px);
      transform:translateX(-50%);
      width:min(320px, 80vw);
      padding:10px 12px;
      border-radius:10px;
      background:#1f2a36;
      color:#fff;
      font-size:12px;
      line-height:1.6;
      box-shadow:0 10px 24px rgba(17,34,68,.22);
      opacity:0;
      pointer-events:none;
      transition:.18s ease;
      white-space:normal;
      z-index:10;
    }
    .tooltip:hover .tip { opacity:1; }
    .range-wrap { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
    .range-wrap input[type='range'] { width:200px; }
    .mode-note {
      margin-top:8px;
      padding:8px 10px;
      border-radius:10px;
      background:#fff;
      border:1px dashed #c9d7e6;
      color:#5b6a78;
      font-size:12px;
      line-height:1.5;
    }
    @media (max-width: 700px) {
      .grid2 { grid-template-columns:1fr; }
      .status-grid { grid-template-columns:1fr; }
      .file-table td.actions { width:auto; }
    }
  </style>
</head>
<body>
  <div class='wrap'>
    <div class='top'>
      <div class='title'>E-paper 管理台</div>
      <div class='meta'>默认首页：设备状态</div>
      <div class='tabs'>
        <button class='tab-btn active' data-tab='status'>设备状态</button>
        <button class='tab-btn' data-tab='config'>配置</button>
        <button class='tab-btn' data-tab='files'>目录</button>
      </div>
    </div>

    <section id='tab-status' class='tab-panel active'>
      <div class='card'>
        <div class='row'>
          <button class='btn primary' onclick='loadStatus()'>刷新状态</button>
          <button class='btn warn' onclick='stopPortal()'>停止 WiFi 门户</button>
        </div>
        <div class='small' style='margin-top:8px'>当前设备状态</div>
        <div class='status-grid'>
          <div class='status-item'><div class='k'>运行模式</div><div class='v' id='st_mode'>--</div></div>
          <div class='status-item'><div class='k'>设备 IP</div><div class='v' id='st_ip'>--</div></div>
          <div class='status-item'><div class='k'>AP IP</div><div class='v' id='st_apip'>--</div></div>
          <div class='status-item'><div class='k'>SD 卡状态</div><div class='v' id='st_sd'>--</div></div>
          <div class='status-item'><div class='k'>已运行时长</div><div class='v' id='st_uptime'>--</div></div>
          <div class='status-item'><div class='k'>超时剩余</div><div class='v' id='st_timeout'>--</div></div>
          <div class='status-item'><div class='k'>温度</div><div class='v' id='st_temp'>未接入</div></div>
          <div class='status-item'><div class='k'>电量</div><div class='v' id='st_battery'>未接入</div></div>
        </div>
        <div id='statusNote' class='notice'></div>
      </div>
    </section>

    <section id='tab-config' class='tab-panel'>
      <div class='card'>
        <div class='grid2'>
          <div class='field'><label>STA SSID</label><input id='ssid'></div>
          <div class='field'><label>STA 密码</label><input id='pass' type='password'></div>
          <div class='field'><label>账号 / 身份</label><input id='staUser'></div>
          <div class='field'><label>连接类型</label><select id='staAuthMode'><option value='auto'>自动</option><option value='personal'>普通密码 WiFi</option><option value='enterprise'>企业/校园网 802.1X</option><option value='open'>开放网络</option><option value='portal'>网页登录认证</option></select></div>
          <div class='field' style='grid-column:1/3'><label>网页登录地址</label><input id='portalLoginUrl' placeholder='例如 http://10.0.0.1/login'></div>
          <div class='field'><label>轮播间隔（秒）</label><input id='sec' type='number' min='30'></div>
          <div class='field' style='grid-column:1/3'><label>天气接口 URL</label><input id='wurl'></div>
        </div>
        <div class='row' style='margin-top:10px'>
          <button class='btn primary' onclick='saveCfg()'>保存配置</button>
          <button class='btn' onclick='testWeather()'>测试天气服务</button>
        </div>
        <pre id='cfgBox' style='margin-top:8px'>等待操作...</pre>
      </div>
    </section>

    <section id='tab-files' class='tab-panel'>
      <div class='card'>
        <div class='path-bar'>
          <div class='path-tools'>
            <button class='btn' onclick='goRoot()'>根目录</button>
            <button class='btn' onclick='goUpDir()'>上一级</button>
            <button class='btn primary' onclick='listFiles()'>刷新目录</button>
          </div>
          <div class='small'>双击目录名或点击进入按钮即可浏览下一层</div>
        </div>
        <div id='crumbs' class='crumbs'></div>
        <div class='quick-links'>
          <button class='btn' onclick='openDir("/pic")'>图片目录 /pic</button>
          <button class='btn' onclick='openDir("/")'>存储根目录 /</button>
        </div>
        <table class='file-table'>
          <thead><tr><th>名称</th><th>大小</th><th>类型</th><th>操作</th></tr></thead>
          <tbody id='fileRows'></tbody>
        </table>
        <div class='small' id='fileSummary' style='margin-top:8px'>等待加载...</div>
      </div>
      <div class='card'>
        <div class='row'>
          <input id='uploadFile' type='file'>
          <select id='uploadMode' style='padding:8px;border:1px solid var(--line);border-radius:8px;min-width:220px;'>
            <option value='normal'>普通文件上传</option>
            <option value='fit'>图片缩放上传</option>
            <option value='crop'>图片裁剪上传</option>
          </select>
          <button class='btn primary' onclick='uploadFile()'>执行上传</button>
        </div>
        <div id='uploadExtra' class='upload-extra'>
          <div class='grid2'>
            <div class='field'>
              <label>抖动算法</label>
              <select id='ditherMode' style='padding:8px;border:1px solid var(--line);border-radius:8px;'>
                <option value='fs_serpentine' selected>Floyd-Steinberg（通用 / 人像推荐）</option>
                <option value='atkinson'>Atkinson（插画 / 图标推荐）</option>
                <option value='jjn'>Jarvis-Judice-Ninke（风景照推荐）</option>
              </select>
              <div id='ditherHint' class='hint-line'></div>
            </div>
            <div class='field'>
              <label style='display:flex;align-items:center;gap:6px;'>
                Gamma
                <span class='tooltip'>?
                  <span class='tip'>推荐值：1.00 为默认通用值；0.90-0.98 适合偏暗照片，可提亮暗部；1.05-1.15 适合风景或高亮场景，层次更稳；高于 1.20 会让画面更重、更深，但暗部细节更容易丢失；低于 0.90 会整体更亮，但可能发灰、对比下降。</span>
                </span>
              </label>
              <div class='range-wrap'>
                <input id='gammaCtrl' type='range' min='0.80' max='1.40' step='0.01' value='1.00'>
                <span id='gammaVal'>1.00</span>
              </div>
              <div id='gammaHint' class='hint-line'></div>
            </div>
          </div>
          <div id='modeNote' class='mode-note'></div>
        </div>
        <pre id='uploadBox' style='margin-top:8px'>等待上传...</pre>
      </div>
    </section>
  </div>

  <script>
    const tabs = [...document.querySelectorAll('.tab-btn')];
    const panels = {
      status: document.getElementById('tab-status'),
      config: document.getElementById('tab-config'),
      files: document.getElementById('tab-files'),
    };
    tabs.forEach(btn => btn.addEventListener('click', () => {
      tabs.forEach(b => b.classList.remove('active'));
      Object.values(panels).forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      panels[btn.dataset.tab].classList.add('active');
    }));
    const statusNote = document.getElementById('statusNote');
    const crumbs = document.getElementById('crumbs');
    const fileRows = document.getElementById('fileRows');
    const fileSummary = document.getElementById('fileSummary');
    const gammaCtrl = document.getElementById('gammaCtrl');
    const gammaVal = document.getElementById('gammaVal');
    const uploadModeSel = document.getElementById('uploadMode');
    const ditherModeSel = document.getElementById('ditherMode');
    const uploadExtra = document.getElementById('uploadExtra');
    const uploadBtn = document.querySelector("button[onclick='uploadFile()']");
    const uploadBox = document.getElementById('uploadBox');
    const ditherHint = document.getElementById('ditherHint');
    const gammaHint = document.getElementById('gammaHint');
    const modeNote = document.getElementById('modeNote');
    let currentDir = '/pic';

    function setNotice(text) {
      if (!statusNote) return;
      if (!text) {
        statusNote.style.display = 'none';
        statusNote.textContent = '';
        return;
      }
      statusNote.style.display = 'block';
      statusNote.textContent = text;
    }

    const syncGammaLabel = () => {
      if (!gammaCtrl || !gammaVal) return;
      const g = Number.parseFloat(gammaCtrl.value);
      gammaVal.textContent = Number.isFinite(g) ? g.toFixed(2) : '1.00';
    };
    const ditherAdvice = {
      fs_serpentine: '通用默认。人像、日常照片优先用这个，边缘和肤色过渡更自然。',
      atkinson: '对比更干净，适合图标、漫画、线稿和高反差插画。',
      jjn: '扩散更平滑，适合风景照、大面积渐变和天空云层。'
    };
    function normalizeDir(path) {
      let out = path || '/';
      if (!out.startsWith('/')) out = '/' + out;
      out = out.replace(/\/+/g, '/');
      if (out.length > 1 && out.endsWith('/')) out = out.slice(0, -1);
      return out || '/';
    }
    function parentDir(path) {
      const dir = normalizeDir(path);
      if (dir === '/') return '/';
      const idx = dir.lastIndexOf('/');
      return idx <= 0 ? '/' : dir.slice(0, idx);
    }
    function joinPath(dir, name){
      const base = normalizeDir(dir);
      if (!name) return base;
      if (name.startsWith('/')) return normalizeDir(name);
      return normalizeDir((base === '/' ? '' : base) + '/' + name);
    }
    function formatSize(bytes) {
      const n = Number(bytes || 0);
      if (n < 1024) return `${n} B`;
      if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
      return `${(n / (1024 * 1024)).toFixed(1)} MB`;
    }
    function renderBreadcrumb(path) {
      const dir = normalizeDir(path);
      crumbs.innerHTML = '';
      const parts = dir === '/' ? [] : dir.slice(1).split('/');
      const rootBtn = document.createElement('button');
      rootBtn.className = 'crumb' + (dir === '/' ? ' current' : '');
      rootBtn.textContent = '/';
      rootBtn.onclick = () => openDir('/');
      crumbs.appendChild(rootBtn);
      let acc = '';
      parts.forEach((part, idx) => {
        const sep = document.createElement('span');
        sep.className = 'small';
        sep.textContent = '/';
        crumbs.appendChild(sep);
        acc += '/' + part;
        const btn = document.createElement('button');
        btn.className = 'crumb' + (idx === parts.length - 1 ? ' current' : '');
        btn.textContent = part;
        const target = acc;
        btn.onclick = () => openDir(target);
        crumbs.appendChild(btn);
      });
    }
    function syncGammaHint() {
      if (!gammaHint || !gammaCtrl) return;
      const g = Number.parseFloat(gammaCtrl.value);
      if (!Number.isFinite(g)) {
        gammaHint.textContent = '当前为默认值。';
      } else if (g < 0.95) {
        gammaHint.textContent = '当前偏亮：暗部会被抬起，适合原图偏暗，但可能降低整体对比。';
      } else if (g <= 1.08) {
        gammaHint.textContent = '当前均衡：适合作为通用起点，先看效果再微调。';
      } else if (g <= 1.20) {
        gammaHint.textContent = '当前偏重：中间调和颜色更扎实，适合风景和高亮场景。';
      } else {
        gammaHint.textContent = '当前较重：画面对比更强，但暗部细节更容易丢失。';
      }
    }
    function syncUploadOptions() {
      const mode = uploadModeSel ? uploadModeSel.value : 'normal';
      const isImageMode = mode === 'fit' || mode === 'crop';
      if (uploadExtra) uploadExtra.classList.toggle('show', isImageMode);
      if (ditherHint && ditherModeSel) {
        ditherHint.textContent = ditherAdvice[ditherModeSel.value] || '';
      }
      if (modeNote) {
        if (mode === 'normal') {
          modeNote.textContent = '普通文件上传会直接保存到当前浏览目录。';
        } else if (mode === 'fit') {
          modeNote.textContent = '图片缩放上传会按比例适配到 800x480，并生成 .epd4 文件后保存到 /pic。';
        } else {
          modeNote.textContent = '图片裁剪上传会优先铺满 800x480，可能裁掉边缘，再生成 .epd4 文件后保存到 /pic。';
        }
      }
      syncGammaHint();
    }
    if (uploadModeSel) {
      uploadModeSel.value = 'normal';
      uploadModeSel.addEventListener('change', syncUploadOptions);
    }
    if (ditherModeSel) {
      ditherModeSel.value = 'fs_serpentine';
      ditherModeSel.addEventListener('change', syncUploadOptions);
    }
    if (gammaCtrl) {
      gammaCtrl.addEventListener('input', syncGammaLabel);
      gammaCtrl.addEventListener('input', syncGammaHint);
    }
    syncGammaLabel();
    syncUploadOptions();

    function fmtMs(ms){
      const s = Math.floor((ms||0)/1000);
      const h = Math.floor(s/3600);
      const m = Math.floor((s%3600)/60);
      const ss = s%60;
      return `${h}h ${m}m ${ss}s`;
    }
    async function loadStatus() {
      const r = await fetch('/api/status');
      const txt = await r.text();
      try {
        const j = JSON.parse(txt);
        document.getElementById('st_mode').textContent = j.state || '--';
        document.getElementById('st_ip').textContent = j.ip || '--';
        document.getElementById('st_apip').textContent = j.ap_ip || '--';
        document.getElementById('st_sd').textContent = j.sd_ready ? '已挂载' : '未挂载';
        document.getElementById('st_uptime').textContent = fmtMs(j.uptime_ms || 0);
        const tmo = j.idle_remaining_ms ?? j.connect_remaining_ms ?? j.session_remaining_ms ?? 0;
        document.getElementById('st_timeout').textContent = fmtMs(tmo);
        document.getElementById('st_temp').textContent = (typeof j.temperature_c === 'number' && j.temperature_c >= -100) ? `${j.temperature_c.toFixed(1)} °C` : '未接入';
        const mv = Number(j.battery_mv || 0);
        const pct = Number(j.battery_pct);
        const pin = j.battery_pin ?? '?';
        if (mv > 0 && Number.isFinite(pct) && pct > 0.1) {
          document.getElementById('st_battery').textContent = `${pct.toFixed(1)}%（${mv} mV，IO${pin}）`;
        } else if (mv > 0) {
          document.getElementById('st_battery').textContent = `${mv} mV（IO${pin}，仅显示电压）`;
        } else {
          document.getElementById('st_battery').textContent = '未接入';
        }
        setNotice('');
      } catch {
        setNotice(txt || '状态读取失败');
      }
    }

    async function loadCfg() {
      const r = await fetch('/api/settings');
      const j = await r.json();
      ssid.value = j.sta_ssid || '';
      staUser.value = j.sta_user || '';
      pass.value = j.sta_pass || '';
      staAuthMode.value = j.sta_auth_mode || 'auto';
      portalLoginUrl.value = j.portal_login_url || '';
      sec.value = j.photo_interval_sec || 300;
      wurl.value = j.weather_url || '';
    }

    async function saveCfg() {
      const body = `sta_ssid=${encodeURIComponent(ssid.value)}&sta_user=${encodeURIComponent(staUser.value)}&sta_pass=${encodeURIComponent(pass.value)}&sta_auth_mode=${encodeURIComponent(staAuthMode.value)}&portal_login_url=${encodeURIComponent(portalLoginUrl.value)}&photo_interval_sec=${encodeURIComponent(sec.value)}&weather_url=${encodeURIComponent(wurl.value)}`;
      const r = await fetch('/api/settings', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
      document.getElementById('cfgBox').textContent = await r.text();
    }

    async function testWeather() {
      const r = await fetch('/api/weather_test');
      document.getElementById('cfgBox').textContent = await r.text();
    }

    async function stopPortal() {
      const r = await fetch('/api/stop', { method:'POST' });
      const txt = await r.text();
      let msg = '停止请求已发送。';
      try {
        const j = JSON.parse(txt);
        if (j && j.ok) {
          msg = j.stopping ? '停止请求已发送，WiFi 门户即将关闭。' : '请求已完成。';
        }
      } catch {}
      setNotice(msg);
    }

    async function openDir(path) {
      currentDir = normalizeDir(path);
      await listFiles(currentDir);
    }
    function goRoot() {
      openDir('/');
    }
    function goUpDir() {
      openDir(parentDir(currentDir));
    }
    async function listFiles(path) {
      const dir = normalizeDir(path || currentDir || '/pic');
      currentDir = dir;
      renderBreadcrumb(dir);
      const r = await fetch('/api/files?path=' + encodeURIComponent(dir));
      const txt = await r.text();
      let j = null;
      try { j = JSON.parse(txt); } catch {}
      fileRows.innerHTML = '';
      if (!j || !j.ok || !Array.isArray(j.items)) {
        fileSummary.textContent = txt || '目录读取失败';
        return;
      }
      currentDir = normalizeDir(j.path || dir);
      renderBreadcrumb(currentDir);
      const items = [...j.items].sort((a, b) => {
        if (!!a.dir !== !!b.dir) return a.dir ? -1 : 1;
        return String(a.name || '').localeCompare(String(b.name || ''), 'zh-Hans-CN');
      });
      let count = 0;
      items.forEach(it => {
        count++;
        const p = joinPath(currentDir, it.name || '');
        const tr = document.createElement('tr');
        tr.innerHTML = `<td></td><td>${it.dir ? '--' : formatSize(it.size || 0)}</td><td><span class="badge${it.dir ? ' dir' : ''}">${it.dir ? '目录' : '文件'}</span></td><td class='actions'></td>`;
        const nameCell = tr.children[0];
        const nameBtn = document.createElement('button');
        nameBtn.className = 'name-btn' + (it.dir ? ' dir' : '');
        nameBtn.textContent = it.name || '';
        if (it.dir) {
          nameBtn.onclick = () => openDir(p);
          nameBtn.ondblclick = () => openDir(p);
        } else {
          nameBtn.onclick = () => window.open('/api/file?path=' + encodeURIComponent(p), '_blank');
        }
        nameCell.appendChild(nameBtn);
        const ops = tr.children[3];
        if (it.dir) {
          const openBtn = document.createElement('button');
          openBtn.className = 'btn';
          openBtn.textContent = '进入';
          openBtn.onclick = () => openDir(p);
          ops.appendChild(openBtn);
        } else {
          const a = document.createElement('a');
          a.href = '/api/file?path=' + encodeURIComponent(p);
          a.textContent = '下载';
          a.style.marginRight = '8px';
          ops.appendChild(a);
          const del = document.createElement('button');
          del.className = 'btn';
          del.textContent = '删除';
          del.onclick = async () => {
            const rr = await fetch('/api/file?path=' + encodeURIComponent(p), { method:'DELETE' });
            alert(await rr.text());
            listFiles(currentDir);
          };
          ops.appendChild(del);
        }
        fileRows.appendChild(tr);
      });
      fileSummary.textContent = `当前位置：${currentDir}，共 ${count} 项`;
    }

    function dist2Weighted(a, b) {
      const dr = a[0] - b[0];
      const dg = a[1] - b[1];
      const db = a[2] - b[2];
      return 3 * dr * dr + 6 * dg * dg + db * db;
    }

    function nearestTwoPalette(rgb, palette) {
      let first = 0;
      let second = 0;
      let best = Number.MAX_SAFE_INTEGER;
      let next = Number.MAX_SAFE_INTEGER;
      for (let pi = 0; pi < palette.length; pi++) {
        const d = dist2Weighted(rgb, palette[pi].rgb);
        if (d < best) {
          next = best;
          second = first;
          best = d;
          first = pi;
        } else if (d < next) {
          next = d;
          second = pi;
        }
      }
      return { first, second, best, next };
    }

    function quantizeImageToEpd4(rgba, W, H, palette, ditherMode, gammaValue) {
      const out = new Uint8Array((W * H) >> 1);
      const pix = new Uint8Array(W * H);

      // Error-diffusion working buffer.
      const work = new Float32Array(W * H * 3);
      const gamma = (Number.isFinite(gammaValue) && gammaValue > 0) ? gammaValue : 1.0;
      const invGamma = 1.0 / gamma;
      for (let i = 0, p = 0; i < W * H; i++, p += 4) {
        const a = rgba[p + 3];
        let r = (a < 8) ? 255 : rgba[p + 0];
        let g = (a < 8) ? 255 : rgba[p + 1];
        let b = (a < 8) ? 255 : rgba[p + 2];
        r = 255 * Math.pow(r / 255, invGamma);
        g = 255 * Math.pow(g / 255, invGamma);
        b = 255 * Math.pow(b / 255, invGamma);
        work[i * 3 + 0] = r;
        work[i * 3 + 1] = g;
        work[i * 3 + 2] = b;
      }

      const clamp255 = (v) => (v < 0 ? 0 : (v > 255 ? 255 : v));
      const addErr = (x, y, er, eg, eb, ratio) => {
        if (x < 0 || x >= W || y < 0 || y >= H) return;
        const idx = (y * W + x) * 3;
        work[idx + 0] += er * ratio;
        work[idx + 1] += eg * ratio;
        work[idx + 2] += eb * ratio;
      };

      const mode = (ditherMode || 'fs_serpentine').toLowerCase();
      for (let y = 0; y < H; y++) {
        const reverse = (mode === 'fs_serpentine' || mode === 'jjn') && ((y & 1) === 1);
        const xStart = reverse ? (W - 1) : 0;
        const xEnd = reverse ? -1 : W;
        const step = reverse ? -1 : 1;
        for (let x = xStart; x !== xEnd; x += step) {
          const wi = (y * W + x) * 3;
          const rgb = [
            clamp255(work[wi + 0]),
            clamp255(work[wi + 1]),
            clamp255(work[wi + 2]),
          ];
          const pick = nearestTwoPalette(rgb, palette);
          const chosen = palette[pick.first].rgb;
          const er = rgb[0] - chosen[0];
          const eg = rgb[1] - chosen[1];
          const eb = rgb[2] - chosen[2];
          pix[y * W + x] = palette[pick.first].nib;

          if (mode === 'fs_serpentine') {
            if (!reverse) {
              addErr(x + 1, y, er, eg, eb, 7 / 16);
              addErr(x - 1, y + 1, er, eg, eb, 3 / 16);
              addErr(x, y + 1, er, eg, eb, 5 / 16);
              addErr(x + 1, y + 1, er, eg, eb, 1 / 16);
            } else {
              addErr(x - 1, y, er, eg, eb, 7 / 16);
              addErr(x + 1, y + 1, er, eg, eb, 3 / 16);
              addErr(x, y + 1, er, eg, eb, 5 / 16);
              addErr(x - 1, y + 1, er, eg, eb, 1 / 16);
            }
          } else if (mode === 'atkinson') {
            const r = 1 / 8;
            addErr(x + 1, y, er, eg, eb, r);
            addErr(x + 2, y, er, eg, eb, r);
            addErr(x - 1, y + 1, er, eg, eb, r);
            addErr(x, y + 1, er, eg, eb, r);
            addErr(x + 1, y + 1, er, eg, eb, r);
            addErr(x, y + 2, er, eg, eb, r);
          } else if (mode === 'jjn') {
            if (!reverse) {
              addErr(x + 1, y, er, eg, eb, 7 / 48);
              addErr(x + 2, y, er, eg, eb, 5 / 48);
              addErr(x - 2, y + 1, er, eg, eb, 3 / 48);
              addErr(x - 1, y + 1, er, eg, eb, 5 / 48);
              addErr(x, y + 1, er, eg, eb, 7 / 48);
              addErr(x + 1, y + 1, er, eg, eb, 5 / 48);
              addErr(x + 2, y + 1, er, eg, eb, 3 / 48);
              addErr(x - 2, y + 2, er, eg, eb, 1 / 48);
              addErr(x - 1, y + 2, er, eg, eb, 3 / 48);
              addErr(x, y + 2, er, eg, eb, 5 / 48);
              addErr(x + 1, y + 2, er, eg, eb, 3 / 48);
              addErr(x + 2, y + 2, er, eg, eb, 1 / 48);
            } else {
              addErr(x - 1, y, er, eg, eb, 7 / 48);
              addErr(x - 2, y, er, eg, eb, 5 / 48);
              addErr(x + 2, y + 1, er, eg, eb, 3 / 48);
              addErr(x + 1, y + 1, er, eg, eb, 5 / 48);
              addErr(x, y + 1, er, eg, eb, 7 / 48);
              addErr(x - 1, y + 1, er, eg, eb, 5 / 48);
              addErr(x - 2, y + 1, er, eg, eb, 3 / 48);
              addErr(x + 2, y + 2, er, eg, eb, 1 / 48);
              addErr(x + 1, y + 2, er, eg, eb, 3 / 48);
              addErr(x, y + 2, er, eg, eb, 5 / 48);
              addErr(x - 1, y + 2, er, eg, eb, 3 / 48);
              addErr(x - 2, y + 2, er, eg, eb, 1 / 48);
            }
          }
        }
      }
      let outIdx = 0;
      for (let i = 0; i < W * H; i += 2) {
        out[outIdx++] = ((pix[i] & 0x0F) << 4) | (pix[i + 1] & 0x0F);
      }
      return out;
    }

    async function preprocessImageToEpd4Blob(file, cropMode, ditherMode = 'fs_serpentine', gammaValue = 1.0) {
      const img = new Image();
      const dataUrl = await new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(fr.result);
        fr.onerror = () => reject(new Error('read_failed'));
        fr.readAsDataURL(file);
      });
      await new Promise((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('decode_failed'));
        img.src = dataUrl;
      });

      const W = 800;
      const H = 480;
      const canvas = document.createElement('canvas');
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      const srcLandscape = img.width >= img.height;
      const frameLandscape = W >= H;
      const rotate90 = (srcLandscape !== frameLandscape);
      const srcW = rotate90 ? img.height : img.width;
      const srcH = rotate90 ? img.width : img.height;
      const sx = W / srcW;
      const sy = H / srcH;
      const scale = cropMode ? Math.max(sx, sy) : Math.min(sx, sy);
      const dw = srcW * scale;
      const dh = srcH * scale;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, W, H);
      if (!rotate90) {
        const dx = (W - dw) * 0.5;
        const dy = (H - dh) * 0.5;
        ctx.drawImage(img, dx, dy, dw, dh);
      } else {
        // Rotate portrait input to landscape first, then apply fit/crop scaling.
        // Use -90deg to match expected orientation on this frame.
        ctx.save();
        ctx.translate(W * 0.5, H * 0.5);
        ctx.rotate(-Math.PI / 2);
        ctx.drawImage(img, -dh * 0.5, -dw * 0.5, dh, dw);
        ctx.restore();
      }
      const rgba = ctx.getImageData(0, 0, W, H).data;

      const paletteNative = [
        { rgb:[0,0,0], nib:0x00 },
        { rgb:[255,255,255], nib:0x01 },
        { rgb:[255,255,0], nib:0x02 }, // yellow
        { rgb:[255,0,0], nib:0x03 },   // red
        { rgb:[0,0,255], nib:0x05 },   // blue
        { rgb:[0,255,0], nib:0x06 },   // green
      ];
      const palette = paletteNative;

      const out = quantizeImageToEpd4(rgba, W, H, palette, ditherMode, gammaValue);
      return new Blob([out], { type: 'application/octet-stream' });
    }

    async function uploadFile() {
      const dir = currentDir || '/';
      const mode = document.getElementById('uploadMode').value || 'normal';
      const ditherMode = document.getElementById('ditherMode')
        ? (document.getElementById('ditherMode').value || 'fs_serpentine')
        : 'fs_serpentine';
      const gammaValue = document.getElementById('gammaCtrl')
        ? Number.parseFloat(document.getElementById('gammaCtrl').value || '1.0')
        : 1.0;
      const gammaText = Number.isFinite(gammaValue) ? gammaValue.toFixed(2) : '1.00';
      const f = document.getElementById('uploadFile').files[0];
      if (uploadBox && f) {
        uploadBox.textContent = `开始上传：模式=${mode}，算法=${ditherMode}，Gamma=${gammaText}，文件=${f.name || 'unknown'}`;
      }
      console.log('[UPLOAD]', { mode, ditherMode, gamma: gammaText, file: f ? (f.name || '') : '' });
      if (!f) {
        document.getElementById('uploadBox').textContent = '请选择要上传的文件';
        return;
      }
      if (mode === 'normal') {
        if (uploadBtn) uploadBtn.disabled = true;
        const fd = new FormData();
        fd.append('file', f);
        const q = '/api/upload?dir=' + encodeURIComponent(dir) + '&mode=normal'
          + '&algo=' + encodeURIComponent(ditherMode)
          + '&gamma=' + encodeURIComponent(gammaText);
        const r = await fetch(q, { method:'POST', body:fd });
        document.getElementById('uploadBox').textContent = await r.text();
        listFiles(currentDir);
        if (uploadBtn) uploadBtn.disabled = false;
        return;
      }
      const lower = (f.name || '').toLowerCase();
      if (!(lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.png') || lower.endsWith('.bmp'))) {
        document.getElementById('uploadBox').textContent = '缩放/裁剪上传仅支持 bmp/jpg/png';
        return;
      }
      document.getElementById('uploadBox').textContent = '正在预处理并转换为 EPD4...';
      if (uploadBtn) uploadBtn.disabled = true;
      try {
        const epdBlob = await preprocessImageToEpd4Blob(f, mode === 'crop', ditherMode, gammaValue);
        const outName = (f.name.replace(/\.[^.]+$/, '') || 'image') + '.epd4';
        const fd = new FormData();
        fd.append('file', epdBlob, outName);
        const q = '/api/upload?dir=' + encodeURIComponent('/pic') + '&mode=normal'
          + '&algo=' + encodeURIComponent(ditherMode)
          + '&gamma=' + encodeURIComponent(gammaText);
        const r = await fetch(q, { method:'POST', body:fd });
        document.getElementById('uploadBox').textContent = await r.text();
        currentDir = '/pic';
        listFiles('/pic');
        if (uploadBtn) uploadBtn.disabled = false;
      } catch (e) {
        if (uploadBtn) uploadBtn.disabled = false;
        document.getElementById('uploadBox').textContent = '预处理失败: ' + (e && e.message ? e.message : String(e));
      }
    }

    loadStatus();
    loadCfg();
    listFiles();
  </script>
</body>
</html>
)HTML";
  server_->send(200, "text/html", html);
}

void WifiManager::handleStatus() {
  markActivity(millis());
  if (kDebugLogs) {
    Serial.printf("[HTTP] GET /api/status from %s\n",
                  server_->client().remoteIP().toString().c_str());
  }
  sampleSensorsNow();
  const char *state_str = "idle";
  if (state_ == State::ApRunning) state_str = "ap_running";
  if (state_ == State::StaConnecting) state_str = "sta_connecting";
  if (state_ == State::StaRunning) state_str = "sta_running";
  String json = "{";
  json += "\"state\":\"";
  json += state_str;
  json += "\",\"ap_active\":";
  json += ap_active_ ? "true" : "false";
  json += ",\"sta_connecting\":";
  json += (state_ == State::StaConnecting) ? "true" : "false";
  json += ",\"sta_connected\":";
  json += (state_ == State::StaRunning && WiFi.status() == WL_CONNECTED) ? "true" : "false";
  json += ",\"sta_ip\":\"";
  json += jsonEscape(WiFi.localIP().toString());
  json += "\",\"ip\":\"";
  json += jsonEscape(WiFi.localIP().toString());
  json += "\",\"ap_ip\":\"";
  json += jsonEscape(WiFi.softAPIP().toString());
  json += "\",\"sd_ready\":";
  json += sd_ready_ ? "true" : "false";
  json += ",\"sd_total_bytes\":";
  json += String(sd_ready_ ? static_cast<uint32_t>(SD.totalBytes()) : 0);
  json += ",\"sd_used_bytes\":";
  json += String(sd_ready_ ? static_cast<uint32_t>(SD.usedBytes()) : 0);
  json += ",\"uptime_ms\":";
  json += String(millis());
  json += ",\"clock_trusted\":";
  json += systemClockTrusted() ? "true" : "false";
  json += ",\"rtc_time_trusted\":";
  json += rtc_time_trusted_ ? "true" : "false";
  json += ",\"epoch\":";
  json += String(static_cast<unsigned long>(time(nullptr)));
  json += ",\"temperature_c\":";
  if (isnan(temperature_c_)) {
    json += "-1000";
  } else {
    json += String(temperature_c_, 1);
  }
  json += ",\"humidity_pct\":";
  if (isnan(humidity_pct_)) {
    json += "-1";
  } else {
    json += String(humidity_pct_, 1);
  }
  json += ",\"battery_mv\":";
  json += String(battery_mv_);
  json += ",\"battery_pin\":";
  json += String(battery_adc_pin_);
  json += ",\"battery_pct\":";
  const float battery_pct = estimateBatteryPercent(battery_mv_);
  if (battery_pct < 0.0f) {
    json += "-1";
  } else {
    json += String(battery_pct, 1);
  }
  json += ",\"weather_city\":\"";
  json += jsonEscape(settings_.weather_city);
  json += "\",\"weather_code\":";
  json += String(weather_code_);
  json += ",\"weather_url\":\"";
  json += jsonEscape(settings_.weather_url);
  json += "\"";
  json += ",\"calendar_sync_pending\":";
  json += calendar_sync_pending_ ? "true" : "false";
  json += ",\"calendar_sync_status\":\"";
  json += jsonEscape(last_calendar_sync_status_);
  json += "\",\"calendar_sync_error\":\"";
  json += jsonEscape(last_calendar_sync_error_);
  json += "\",\"calendar_sync_epoch\":";
  json += String(static_cast<unsigned long>(last_calendar_sync_epoch_));
  json += ",\"calendar_sync_vevents\":";
  json += String(last_calendar_sync_vevents_);
  json += ",\"calendar_sync_imported\":";
  json += String(last_calendar_sync_imported_);
  json += ",\"calendar_sync_total\":";
  json += String(last_calendar_sync_total_);
  if (state_ == State::ApRunning) {
    const uint32_t remain =
        (millis() - last_activity_ms_ >= kApIdleTimeoutMs)
            ? 0
            : (kApIdleTimeoutMs - (millis() - last_activity_ms_));
    json += ",\"idle_remaining_ms\":";
    json += String(remain);
  } else if (state_ == State::StaConnecting) {
    const uint32_t remain =
        (millis() - sta_connect_start_ms_ >= sta_connect_timeout_ms_)
            ? 0
            : (sta_connect_timeout_ms_ - (millis() - sta_connect_start_ms_));
    json += ",\"connect_remaining_ms\":";
    json += String(remain);
  } else if (state_ == State::StaRunning) {
    const uint32_t remain =
        (millis() - last_activity_ms_ >= kStaSessionTimeoutMs)
            ? 0
            : (kStaSessionTimeoutMs - (millis() - last_activity_ms_));
    json += ",\"idle_remaining_ms\":";
    json += String(remain);
  }
  json += "}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleSettingsGet() {
  markActivity(millis());
  if (kDebugLogs) {
    Serial.printf("[HTTP] GET /api/settings from %s\n",
                  server_->client().remoteIP().toString().c_str());
  }
  String json = "{";
  json += "\"sta_ssid\":\"" + jsonEscape(settings_.sta_ssid) + "\",";
  json += "\"sta_user\":\"" + jsonEscape(settings_.sta_user) + "\",";
  json += "\"sta_pass\":\"" + jsonEscape(settings_.sta_pass) + "\",";
  json += "\"sta_auth_mode\":\"" + jsonEscape(settings_.sta_auth_mode) + "\",";
  json += "\"portal_login_url\":\"" + jsonEscape(settings_.portal_login_url) + "\",";
  json += "\"ui_language\":\"" + jsonEscape(settings_.ui_language) + "\",";
  json += "\"timezone\":\"" + jsonEscape(settings_.timezone) + "\",";
  json += "\"photo_interval_sec\":" + String(settings_.photo_interval_sec) + ",";
  json += "\"app_auto_switch_enabled\":";
  json += settings_.app_auto_switch_enabled ? "true," : "false,";
  json += "\"app_switch_interval_sec\":" + String(settings_.app_switch_interval_sec) + ",";
  json += "\"calendar_enabled\":";
  json += settings_.calendar_enabled ? "true," : "false,";
  json += "\"calendar_layout\":\"" + jsonEscape(settings_.calendar_layout) + "\",";
  json += "\"calendar_refresh_sec\":" + String(settings_.calendar_refresh_sec) + ",";
  json += "\"calendar_time_refresh_sec\":" + String(settings_.calendar_time_refresh_sec) + ",";
  json += "\"sleep_start\":\"" + formatMinuteHm(settings_.sleep_start_minute) + "\",";
  json += "\"sleep_end\":\"" + formatMinuteHm(settings_.sleep_end_minute) + "\",";
  json += "\"calendar_url\":\"" + jsonEscape(settings_.calendar_url) + "\",";
  json += "\"weather_city\":\"" + jsonEscape(settings_.weather_city) + "\",";
  json += "\"weather_lat\":\"" + jsonEscape(settings_.weather_lat) + "\",";
  json += "\"weather_lon\":\"" + jsonEscape(settings_.weather_lon) + "\",";
  json += "\"weather_url\":\"" + jsonEscape(settings_.weather_url) + "\"";
  json += "}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleSettingsPost() {
  markActivity(millis());
  Serial.printf("[HTTP] POST /api/settings from %s\n",
                server_->client().remoteIP().toString().c_str());
  const bool previous_calendar_enabled = settings_.calendar_enabled;
  const String previous_calendar_url = settings_.calendar_url;
  const uint32_t previous_calendar_refresh_sec = settings_.calendar_refresh_sec;
  const String previous_weather_url = settings_.weather_url;
  if (server_->hasArg("sta_ssid")) settings_.sta_ssid = server_->arg("sta_ssid");
  if (server_->hasArg("sta_user")) settings_.sta_user = server_->arg("sta_user");
  if (server_->hasArg("sta_pass")) settings_.sta_pass = server_->arg("sta_pass");
  if (server_->hasArg("sta_auth_mode")) settings_.sta_auth_mode = server_->arg("sta_auth_mode");
  if (server_->hasArg("portal_login_url")) {
    settings_.portal_login_url = server_->arg("portal_login_url");
  }
  if (server_->hasArg("ui_language")) settings_.ui_language = server_->arg("ui_language");
  if (server_->hasArg("photo_interval_sec")) {
    settings_.photo_interval_sec = static_cast<uint32_t>(server_->arg("photo_interval_sec").toInt());
    if (settings_.photo_interval_sec < 30) settings_.photo_interval_sec = 30;
    if (settings_.photo_interval_sec > 86400) settings_.photo_interval_sec = 86400;
  }
  if (server_->hasArg("app_auto_switch_enabled")) {
    const String enabled = server_->arg("app_auto_switch_enabled");
    settings_.app_auto_switch_enabled = (enabled == "1" || enabled == "true" || enabled == "on");
  } else if (server_->hasArg("app_auto_switch")) {
    const String enabled = server_->arg("app_auto_switch");
    settings_.app_auto_switch_enabled = (enabled == "1" || enabled == "true" || enabled == "on");
  }
  if (server_->hasArg("app_switch_interval_sec")) {
    settings_.app_switch_interval_sec =
        static_cast<uint32_t>(server_->arg("app_switch_interval_sec").toInt());
    if (settings_.app_switch_interval_sec < 60) settings_.app_switch_interval_sec = 60;
    if (settings_.app_switch_interval_sec > 86400) settings_.app_switch_interval_sec = 86400;
  }
  if (server_->hasArg("calendar_enabled")) {
    const String enabled = server_->arg("calendar_enabled");
    settings_.calendar_enabled = (enabled == "1" || enabled == "true" || enabled == "on");
  }
  if (server_->hasArg("calendar_layout")) settings_.calendar_layout = server_->arg("calendar_layout");
  if (server_->hasArg("calendar_refresh_sec")) {
    settings_.calendar_refresh_sec =
        static_cast<uint32_t>(server_->arg("calendar_refresh_sec").toInt());
    if (settings_.calendar_refresh_sec < 60) settings_.calendar_refresh_sec = 60;
    if (settings_.calendar_refresh_sec > 86400) settings_.calendar_refresh_sec = 86400;
  }
  if (server_->hasArg("calendar_time_refresh_sec")) {
    settings_.calendar_time_refresh_sec = normalizeCalendarTimeRefreshSec(
        static_cast<uint32_t>(server_->arg("calendar_time_refresh_sec").toInt()));
  }
  if (server_->hasArg("sleep_start")) {
    uint16_t minute = settings_.sleep_start_minute;
    if (parseMinuteHm(server_->arg("sleep_start"), minute)) {
      settings_.sleep_start_minute = minute;
    }
  }
  if (server_->hasArg("sleep_end")) {
    uint16_t minute = settings_.sleep_end_minute;
    if (parseMinuteHm(server_->arg("sleep_end"), minute)) {
      settings_.sleep_end_minute = minute;
    }
  }
  if (server_->hasArg("calendar_url")) settings_.calendar_url = server_->arg("calendar_url");
  if (server_->hasArg("weather_city")) settings_.weather_city = server_->arg("weather_city");
  if (server_->hasArg("weather_lat")) settings_.weather_lat = server_->arg("weather_lat");
  if (server_->hasArg("weather_lon")) settings_.weather_lon = server_->arg("weather_lon");
  if (server_->hasArg("weather_url")) settings_.weather_url = server_->arg("weather_url");

  SettingsStore::normalize(settings_);
  if (settings_.sta_ssid.length() == 0) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"empty_sta_ssid\"}");
    return;
  }
  SettingsStore::fillEmptyValues(settings_);

  if (state_ == State::StaRunning &&
      (settings_.calendar_enabled != previous_calendar_enabled ||
       settings_.calendar_url != previous_calendar_url ||
       settings_.calendar_refresh_sec != previous_calendar_refresh_sec)) {
    calendar_sync_pending_ = true;
    last_calendar_sync_ms_ = 0;
  }

  if (!saveSettings()) {
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"save_failed\"}");
    return;
  }
  settings_apply_refresh_pending_ = true;
  server_->send(200, "application/json", "{\"ok\":true}");
}

void WifiManager::handleCalendarEventsGet() {
  markActivity(millis());
  if (kDebugLogs) {
    Serial.printf("[HTTP] GET /api/calendar/events from %s\n",
                  server_->client().remoteIP().toString().c_str());
  }
  constexpr size_t kMaxUpcomingEvents = 5u;
  std::vector<UpcomingCalendarEvent> upcoming;
  upcoming.reserve(kMaxUpcomingEvents + calendar_store_.count());
  const time_t now_epoch = time(nullptr);
  uint16_t order = 0;
  for (size_t i = 0; i < calendar_store_.count(); ++i) {
    CalendarEvent event;
    if (!calendar_store_.eventAt(i, event)) {
      continue;
    }
    time_t next_epoch = 0;
    String occurrence_date;
    if (!nextManualEventEpoch(event, now_epoch, next_epoch, occurrence_date)) {
      continue;
    }
    event.date = occurrence_date;
    UpcomingCalendarEvent item;
    item.event = event;
    item.epoch = next_epoch;
    item.order = order++;
    upcoming.push_back(item);
  }
  std::sort(upcoming.begin(), upcoming.end(), upcomingEventLess);

  server_->sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  server_->sendHeader("Pragma", "no-cache");
  server_->setContentLength(CONTENT_LENGTH_UNKNOWN);
  server_->send(200, "application/json; charset=utf-8", "");
  server_->sendContent("{\"ok\":true,\"items\":[");
  const size_t send_count = std::min(upcoming.size(), kMaxUpcomingEvents);
  for (size_t i = 0; i < send_count; ++i) {
    String item;
    item.reserve(240);
    if (i > 0) {
      item += ",";
    }
    appendCalendarEventJson(item, upcoming[i].event);
    server_->sendContent(item);
  }
  server_->sendContent("],\"total\":");
  server_->sendContent(String(upcoming.size()));
  server_->sendContent(",\"shown\":");
  server_->sendContent(String(send_count));
  server_->sendContent("}");
}

void WifiManager::handleCalendarEventsPost() {
  markActivity(millis());
  Serial.printf("[HTTP] POST /api/calendar/events from %s\n",
                server_->client().remoteIP().toString().c_str());

  CalendarEvent e;
  e.title = server_->hasArg("title") ? server_->arg("title") : "Event";
  e.title.trim();
  if (e.title.length() == 0) {
    e.title = "Event";
  }
  if (e.title.length() > 32) {
    e.title = e.title.substring(0, 32);
  }
  if (server_->hasArg("location")) {
    e.title = buildImportedTitle(e.title, server_->arg("location"), "");
  }
  if (!server_->hasArg("time")) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_time\"}");
    return;
  }
  String normalized_time;
  String normalized_end_time;
  if (!normalizeCalendarTimeValue(server_->arg("time"), normalized_time)) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_time\"}");
    return;
  }
  e.time_hhmm = normalized_time;
  if (server_->hasArg("end_time")) {
    const String end_time = server_->arg("end_time");
    if (end_time.length() > 0) {
      if (!normalizeCalendarTimeValue(end_time, normalized_end_time)) {
        server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_end_time\"}");
        return;
      }
      e.end_time_hhmm = normalized_end_time;
    } else {
      e.end_time_hhmm = "";
    }
  } else {
    e.end_time_hhmm = "";
  }
  e.color =
      normalizeCalendarColorValue(server_->hasArg("color") ? server_->arg("color") : "blue");
  e.repeat =
      normalizeCalendarRepeatValue(server_->hasArg("repeat") ? server_->arg("repeat") : "weekly");
  e.source =
      normalizeCalendarSourceValue(server_->hasArg("source") ? server_->arg("source") : "manual");
  e.external_id =
      normalizeCalendarExternalIdValue(server_->hasArg("external_id") ? server_->arg("external_id")
                                                                      : "");
  if (server_->hasArg("updated_at")) {
    e.updated_at = normalizeCalendarUpdatedAtValue(server_->arg("updated_at"));
  } else {
    const time_t now_ts = time(nullptr);
    if (now_ts > 0) {
      e.updated_at = String(static_cast<unsigned long>(now_ts));
    } else {
      e.updated_at = "";
    }
  }

  if (e.repeat == "once") {
    if (!server_->hasArg("date")) {
      server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_date\"}");
      return;
    }
    String normalized_date;
    if (!normalizeCalendarDateValue(server_->arg("date"), normalized_date)) {
      server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_date\"}");
      return;
    }
    e.date = normalized_date;
    e.weekday = -1;
  } else if (e.repeat == "weekly") {
    if (!server_->hasArg("weekday")) {
      server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_weekday\"}");
      return;
    }
    const int weekday = server_->arg("weekday").toInt();
    if (weekday < 0 || weekday > 6) {
      server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_weekday\"}");
      return;
    }
    e.weekday = static_cast<int8_t>(weekday);
    e.date = "";
  } else {
    e.weekday = -1;
    e.date = "";
  }
  const int existing_idx = calendar_store_.findIndexByExternal(e.source, e.external_id);
  CalendarEvent previous_event;
  CalendarEvent evicted_event;
  bool updated_existing = false;
  bool evicted_ics = false;
  bool inserted_new = false;
  if (existing_idx >= 0) {
    previous_event = calendar_store_.data()[existing_idx];
    e.id = calendar_store_.data()[existing_idx].id;
    calendar_store_.data()[existing_idx] = e;
    updated_existing = true;
  } else {
    if (calendar_store_.count() >= static_cast<size_t>(kMaxCalendarEvents)) {
      const int evict_ics_index = calendar_store_.findLastIndexBySource("ics");
      if (evict_ics_index >= 0) {
        calendar_store_.eventAt(static_cast<size_t>(evict_ics_index), evicted_event);
        calendar_store_.removeAt(static_cast<size_t>(evict_ics_index));
        evicted_ics = true;
        Serial.println("[CAL] evicted one cached ICS event to add manual event");
      } else {
        server_->send(409, "application/json",
                      "{\"ok\":false,\"error\":\"manual_calendar_events_full\"}");
        return;
      }
    }
    e.id = calendar_store_.allocateId();
    if (!calendar_store_.push(e)) {
      if (evicted_ics) {
        calendar_store_.push(evicted_event);
      }
      server_->send(500, "application/json", "{\"ok\":false,\"error\":\"store_push_failed\"}");
      return;
    }
    inserted_new = true;
  }
  if (!saveSettings()) {
    if (updated_existing && existing_idx >= 0) {
      calendar_store_.data()[existing_idx] = previous_event;
    } else if (inserted_new) {
      const int inserted_idx = calendar_store_.findIndexById(e.id);
      if (inserted_idx >= 0) {
        calendar_store_.removeAt(static_cast<size_t>(inserted_idx));
      }
      if (evicted_ics) {
        calendar_store_.push(evicted_event);
      }
    }
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"save_failed\"}");
    return;
  }
  String json = "{\"ok\":true,\"id\":";
  json += String(e.id);
  json += "}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleCalendarEventsDelete() {
  markActivity(millis());
  Serial.printf("[HTTP] DELETE /api/calendar/events from %s\n",
                server_->client().remoteIP().toString().c_str());
  int idx = -1;
  if (server_->hasArg("id")) {
    const uint16_t id = static_cast<uint16_t>(server_->arg("id").toInt());
    idx = calendar_store_.findIndexById(id);
  } else if (server_->hasArg("source") && server_->hasArg("external_id")) {
    const String source = normalizeCalendarSourceValue(server_->arg("source"));
    const String external_id = normalizeCalendarExternalIdValue(server_->arg("external_id"));
    idx = calendar_store_.findIndexByExternal(source, external_id);
  } else {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_id_or_external\"}");
    return;
  }
  if (idx < 0) {
    server_->send(404, "application/json", "{\"ok\":false,\"error\":\"event_not_found\"}");
    return;
  }
  CalendarEvent target;
  if (calendar_store_.eventAt(static_cast<size_t>(idx), target) && target.source == "ics") {
    server_->send(403, "application/json", "{\"ok\":false,\"error\":\"ics_event_readonly\"}");
    return;
  }

  const uint16_t deleted_id = target.id;
  calendar_store_.removeAt(static_cast<size_t>(idx));
  if (!saveSettings()) {
    calendar_store_.push(target);
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"save_failed\"}");
    return;
  }
  String json = "{\"ok\":true,\"id\":";
  json += String(deleted_id);
  json += "}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleGeocode() {
  markActivity(millis());
  if (state_ != State::StaRunning || WiFi.status() != WL_CONNECTED) {
    server_->send(400, "application/json",
                  "{\"ok\":false,\"error\":\"sta_required\",\"msg\":\"geocode requires STA connected\"}");
    return;
  }
  if (!server_->hasArg("city")) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_city\"}");
    return;
  }
  String city = server_->arg("city");
  city.trim();
  if (city.length() == 0) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"empty_city\"}");
    return;
  }

  String url = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=zh&format=json&name=";
  url += urlEncode(city);
  Serial.printf("[HTTP] GET /api/geocode city=%s\n", city.c_str());

  HTTPClient http;
  http.setConnectTimeout(8000);
  http.setTimeout(8000);
  if (!http.begin(url)) {
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"http_begin_failed\"}");
    return;
  }
  const int code = http.GET();
  if (code != 200) {
    http.end();
    server_->send(502, "application/json", "{\"ok\":false,\"error\":\"geocode_http_failed\"}");
    return;
  }
  const String body = http.getString();
  http.end();

  const int results_idx = body.indexOf("\"results\":[");
  if (results_idx < 0) {
    server_->send(404, "application/json", "{\"ok\":false,\"error\":\"city_not_found\"}");
    return;
  }

  const int name_key = body.indexOf("\"name\":\"", results_idx);
  const int lat_key = body.indexOf("\"latitude\":", results_idx);
  const int lon_key = body.indexOf("\"longitude\":", results_idx);
  if (name_key < 0 || lat_key < 0 || lon_key < 0) {
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"geocode_parse_failed\"}");
    return;
  }

  const int name_start = name_key + 8;
  const int name_end = body.indexOf('"', name_start);
  const int lat_start = lat_key + 11;
  int lat_end = body.indexOf(',', lat_start);
  const int lon_start = lon_key + 12;
  int lon_end = body.indexOf(',', lon_start);
  if (lat_end < 0) lat_end = body.indexOf('}', lat_start);
  if (lon_end < 0) lon_end = body.indexOf('}', lon_start);
  if (name_end < 0 || lat_end < 0 || lon_end < 0) {
    server_->send(500, "application/json", "{\"ok\":false,\"error\":\"geocode_parse_failed\"}");
    return;
  }

  String resolved_name = body.substring(name_start, name_end);
  String lat = body.substring(lat_start, lat_end);
  String lon = body.substring(lon_start, lon_end);
  lat.trim();
  lon.trim();

  String json = "{\"ok\":true,\"city\":\"";
  json += jsonEscape(resolved_name);
  json += "\",\"lat\":\"";
  json += jsonEscape(lat);
  json += "\",\"lon\":\"";
  json += jsonEscape(lon);
  json += "\",\"weather_url\":\"http://api.open-meteo.com/v1/forecast?latitude=";
  json += jsonEscape(lat);
  json += "&longitude=";
  json += jsonEscape(lon);
  json += "&current=temperature_2m,relative_humidity_2m,weather_code&timezone=auto\"}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleFilesList() {
  markActivity(millis());
  const String path = server_->hasArg("path") ? server_->arg("path") : "/pic";
  Serial.printf("[HTTP] GET /api/files path=%s\n", path.c_str());
  if (!isSafePath(path)) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_path\"}");
    return;
  }
  server_->send(200, "application/json", listDirectoryJson(path.c_str()));
}

void WifiManager::handleDirCreate() {
  markActivity(millis());
  if (!sd_ready_) {
    server_->send(503, "application/json", "{\"ok\":false,\"error\":\"sd_not_ready\"}");
    return;
  }
  if (!server_->hasArg("path")) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_path\"}");
    return;
  }
  String path = server_->arg("path");
  path.trim();
  Serial.printf("[HTTP] POST /api/dir path=%s\n", path.c_str());
  if (!isSafePath(path) || path == "/") {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_path\"}");
    return;
  }
  if (SD.exists(path)) {
    server_->send(409, "application/json", "{\"ok\":false,\"error\":\"already_exists\"}");
    return;
  }
  const bool ok = SD.mkdir(path);
  server_->send(ok ? 200 : 500, "application/json", ok ? "{\"ok\":true}" : "{\"ok\":false}");
}

void WifiManager::handleFileDownload() {
  markActivity(millis());
  if (!sd_ready_) {
    server_->send(503, "application/json", "{\"ok\":false,\"error\":\"sd_not_ready\"}");
    return;
  }
  if (!server_->hasArg("path")) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_path\"}");
    return;
  }
  const String path = server_->arg("path");
  Serial.printf("[HTTP] GET /api/file path=%s\n", path.c_str());
  if (!isSafePath(path)) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_path\"}");
    return;
  }
  File file = SD.open(path, FILE_READ);
  if (!file) {
    server_->send(404, "application/json", "{\"ok\":false,\"error\":\"not_found\"}");
    return;
  }
  server_->streamFile(file, contentTypeForPath(path));
  file.close();
}

void WifiManager::handleFileDelete() {
  markActivity(millis());
  if (!sd_ready_) {
    server_->send(503, "application/json", "{\"ok\":false,\"error\":\"sd_not_ready\"}");
    return;
  }
  if (!server_->hasArg("path")) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"missing_path\"}");
    return;
  }
  const String path = server_->arg("path");
  Serial.printf("[HTTP] DELETE /api/file path=%s\n", path.c_str());
  if (!isSafePath(path) || path == "/") {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_path\"}");
    return;
  }
  const bool ok = removePathRecursive(path);
  server_->send(ok ? 200 : 500, "application/json", ok ? "{\"ok\":true}" : "{\"ok\":false}");
}

void WifiManager::handleWeatherTest() {
  markActivity(millis());
  Serial.printf("[HTTP] GET /api/weather_test url=%s\n", settings_.weather_url.c_str());

  if (state_ != State::StaRunning || WiFi.status() != WL_CONNECTED) {
    server_->send(400, "application/json",
                  "{\"ok\":false,\"error\":\"sta_required\",\"msg\":\"weather test requires STA connected\"}");
    return;
  }
  if (!(settings_.weather_url.startsWith("http://") || settings_.weather_url.startsWith("https://"))) {
    server_->send(400, "application/json", "{\"ok\":false,\"error\":\"bad_weather_url\"}");
    return;
  }

  String resolved_timezone;
  bool timezone_updated = false;
  String local_time;
  String time_sync_error;
  String preview;
  int code = 0;
  String request_error;
  const bool time_sync_ok = syncClockFromWeather(resolved_timezone, timezone_updated, local_time,
                                                 time_sync_error, preview, code, request_error);
  if (code <= 0) {
    const int status = (request_error == "bad_weather_url") ? 400 : 502;
    server_->send(status, "application/json",
                  String("{\"ok\":false,\"error\":\"") + request_error + "\"}");
    return;
  }
  if (time_sync_ok) {
    Serial.printf("[TIME] weather sync ok tz=%s local=%s\n",
                  resolved_timezone.c_str(), local_time.c_str());
    writeClockToRtc("weather_test");
  } else {
    Serial.printf("[TIME] weather sync failed tz=%s err=%s\n",
                  resolved_timezone.c_str(), time_sync_error.c_str());
  }
  String json = "{";
  json += "\"ok\":true,";
  json += "\"msg\":\"weather_request_ok\",";
  json += "\"http_status\":";
  json += String(code);
  json += ",\"weather_code\":";
  json += String(weather_code_);
  json += ",\"url\":\"";
  json += jsonEscape(settings_.weather_url);
  json += "\",\"preview\":\"";
  json += jsonEscape(preview);
  json += "\",\"ip\":\"";
  json += jsonEscape(WiFi.localIP().toString());
  json += "\",\"timezone\":\"";
  json += jsonEscape(resolved_timezone);
  json += "\",\"timezone_updated\":";
  json += timezone_updated ? "true" : "false";
  json += ",\"time_sync_ok\":";
  json += time_sync_ok ? "true" : "false";
  json += ",\"local_time\":\"";
  json += jsonEscape(local_time);
  json += "\",\"time_sync_error\":\"";
  json += jsonEscape(time_sync_error);
  json += "\"}";
  server_->send(200, "application/json", json);
}

void WifiManager::handleStopPortal() {
  markActivity(millis());
  Serial.printf("[HTTP] POST /api/stop from %s\n",
                server_->client().remoteIP().toString().c_str());
  server_->send(200, "application/json", "{\"ok\":true,\"stopping\":true}");
  stop("manual_http_stop");
  auto_exit_requested_ = true;
}

void WifiManager::handleReboot() {
  markActivity(millis());
  Serial.printf("[HTTP] POST /api/reboot from %s\n",
                server_->client().remoteIP().toString().c_str());
  server_->send(200, "application/json", "{\"ok\":true,\"rebooting\":true}");
  delay(200);
  ESP.restart();
}

void WifiManager::handleFileUpload() {
  markActivity(millis());
  static File upload_file;
  static String upload_algo;
  static String upload_gamma;
  HTTPUpload &upload = server_->upload();

  if (upload.status == UPLOAD_FILE_START) {
    upload_ok_ = true;
    upload_error_ = "";
    upload_mode_ = server_->hasArg("mode") ? server_->arg("mode") : "normal";
    upload_mode_.toLowerCase();
    upload_algo = server_->hasArg("algo") ? server_->arg("algo") : "none";
    upload_gamma = server_->hasArg("gamma") ? server_->arg("gamma") : "1.00";
    upload_tmp_path_ = "";
    Serial.printf("[UPLOAD] begin mode=%s algo=%s gamma=%s remote=%s\n",
                  upload_mode_.c_str(),
                  upload_algo.c_str(),
                  upload_gamma.c_str(),
                  server_->client().remoteIP().toString().c_str());
  }

  if (!sd_ready_) {
    upload_ok_ = false;
    upload_error_ = "sd_not_ready";
    if (upload.status == UPLOAD_FILE_START) {
      Serial.printf("[UPLOAD] reject err=%s\n", upload_error_.c_str());
    }
    return;
  }

  String filename = upload.filename;
  filename.replace("\\", "");
  filename.replace("/", "");
  if (filename.length() == 0) {
    upload_ok_ = false;
    upload_error_ = "bad_filename";
    return;
  }

  const bool preprocess_mode = (upload_mode_ == "fit" || upload_mode_ == "crop");
  const String dir = server_->hasArg("dir") ? server_->arg("dir") : "/";
  if (!isSafePath(dir)) {
    upload_ok_ = false;
    upload_error_ = "bad_dir";
    if (upload.status == UPLOAD_FILE_START) {
      Serial.printf("[SD] upload rejected bad dir=%s\n", dir.c_str());
    }
    return;
  }
  String filepath = dir;
  if (!filepath.endsWith("/")) {
    filepath += "/";
  }
  filepath += filename;
  upload_tmp_path_ = filepath;

  if (upload.status == UPLOAD_FILE_START) {
    if (preprocess_mode) {
      upload_ok_ = false;
      upload_error_ = "server_preprocess_disabled_use_browser";
      Serial.printf("[UPLOAD] reject mode=%s err=%s\n", upload_mode_.c_str(),
                    upload_error_.c_str());
      return;
    }
    const int slash = filepath.lastIndexOf('/');
    const String parent = (slash > 0) ? filepath.substring(0, slash) : "/";
    if (parent.length() > 0 && !SD.exists(parent)) {
      SD.mkdir(parent);
    }
    if (SD.exists(filepath)) {
      SD.remove(filepath);
    }
    upload_file = SD.open(filepath, FILE_WRITE);
    if (!upload_file) {
      upload_ok_ = false;
      upload_error_ = "open_failed";
      Serial.printf("[SD] upload open failed %s\n", filepath.c_str());
      return;
    }
    Serial.printf("[SD] upload start %s\n", filepath.c_str());
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (upload_file) {
      upload_file.write(upload.buf, upload.currentSize);
    } else {
      upload_ok_ = false;
      upload_error_ = "write_target_missing";
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (upload_file) {
      upload_file.close();
    }
    Serial.printf("[SD] upload done %s size=%u mode=%s algo=%s gamma=%s\n",
                  filepath.c_str(), upload.totalSize,
                  upload_mode_.c_str(),
                  upload_algo.c_str(),
                  upload_gamma.c_str());

    if (!upload_ok_) {
      SD.remove(filepath);
      Serial.printf("[UPLOAD] end with prior error=%s cleaned=%s\n", upload_error_.c_str(),
                    filepath.c_str());
      return;
    }

    if (upload_ok_) {
      Serial.printf("[UPLOAD] done ok mode=%s algo=%s gamma=%s final=%s\n",
                    upload_mode_.c_str(),
                    upload_algo.c_str(),
                    upload_gamma.c_str(),
                    filepath.c_str());
    }
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    upload_ok_ = false;
    upload_error_ = "aborted";
    if (upload_file) {
      upload_file.close();
    }
    if (upload_tmp_path_.length() > 0) {
      SD.remove(upload_tmp_path_);
      Serial.printf("[SD] upload aborted %s\n", upload_tmp_path_.c_str());
    }
    Serial.printf("[UPLOAD] aborted err=%s\n", upload_error_.c_str());
  }
}

void WifiManager::handleNotFound() {
  markActivity(millis());
  server_->send(404, "application/json", "{\"ok\":false,\"error\":\"not_found\"}");
}

}  // namespace appfw
